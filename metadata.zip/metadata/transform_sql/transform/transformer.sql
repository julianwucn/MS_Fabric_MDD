select 
    store 
    ,s.date
    ,s.check_num
    ,s.disc_num
    ,coalesce(s.overring, false) as overring
    ,s.table
    ,s.cost_centr
    ,s.user_num
    ,s.time
    ,s.shift
    ,s.num_party
    ,s.amount
    ,s.tax_total
    ,s.disc_print
    ,s.deliv_time
    ,s.serv_time
    ,s.seq_num
    ,s.disc_mngr
    ,s.co_seq_hse
    ,s.co_seq_trm
    ,s.co_seq_usr
    ,s.pay_term
    ,s.pay_drawer
    ,s.pay_cashr
    ,s.us_slswtx
    ,s.pay_time
    ,s.co_seq_csh
    ,s.station_no
    ,s.open_dollr
    ,s.open_prcnt
    ,s.tax_1
    ,s.tax_2
    ,s.tax_3
    ,s.tax_4
    ,s.sub_chk_no
    ,s.gratuity
    ,s.grat_no
    ,coalesce(s.adjustment, false) as adjustment
    ,coalesce(s.refund, false)     as refund
    ,coalesce(s.dummy, false)      as dummy
    ,coalesce(s.is_check, false)   as is_check
    ,year(s.date)                  as partition_year
    ,month(s.date)                 as partition_month

    ,s._deleted_by_source
    ,s._deleted_by_validation
    ,s._record_timestamp
    ,s._change_type
    ,s._commit_version
    ,s._commit_timestamp     
from vw_temp_source_data_uuid s
--from bronze.posi_checkheader s