#!/usr/bin/env python
# coding: utf-8

# ## transform_silver_mdd_checkitems
# 
# New notebook

# In[1]:


from env.mdd.transformer import TransformerAbs

from pyspark.sql.functions import *


# In[2]:


class transformer_1(TransformerAbs):

    def __init__(self, schema_bronze, schema_silver, schema_gold, spark, logger, debug):
        super().__init__(schema_bronze, schema_silver, schema_gold, spark, logger, debug)

    def transform(self, data_df):
        function_name = "transform"
        if self.debug:
            self.logger.debug(f"function begin: {function_name}")
       
        # test code
        transformed_data_df = data_df.withColumn("major", col("major")*10) \
                                    .withColumn("minor", col("minor")*10) \
                                    .withColumn("partition_year", expr("year(date)")) \
                                    .withColumn("partition_month", expr("month(date)")) \
                                    .drop("file_store") \
                                    .drop("file_date") \
                                    .drop("file_year") \
                                    .drop("file_month")
        
        if self.debug:
            self.logger.debug(f"function end: {function_name}")

        return  transformed_data_df

