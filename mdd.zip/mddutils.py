#!/usr/bin/env python
# coding: utf-8

# ## mddutils
# 
# New notebook

# In[12]:


import re
import json
import uuid
import logging
import posixpath
import notebookutils
import datetime as mdt
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import DeltaTable


from env.mdd.metadata import *
from env.mdd.environment import Environment


# In[13]:


import logging
import inspect
from functools import wraps

class DecoratorUtil:
    @staticmethod
    def add_logger():
        """Class decorator to add a logger to the class."""
        def decorator(cls):
            cls.logger = logging.getLogger(f"mdd.{cls.__name__}")
            return cls
        return decorator

    @staticmethod
    def _get_clean_call_trace(self_obj, target_func: str, max_depth=10) -> str:
        """
        Returns a clean call trace (e.g., foo -> bar), showing only methods of the same instance
        and excluding the decorator wrapper itself.

        Args:
            self_obj: Instance (`self`) of the current class
            target_func: The actual function being decorated
            max_depth: Stack depth

        Returns:
            str: Clean trace string
        """
        trace = []
        stack = inspect.stack()

        for frame in stack[1:max_depth + 1]:
            frame_self = frame.frame.f_locals.get("self")
            func_name = frame.function

            # Keep only frames from this object
            if frame_self is self_obj:
                # Exclude decorator's internal `wrapper` frame
                if func_name != "wrapper":
                    trace.append(func_name)

        # Add the actual decorated function name at the end
        if not trace or trace[-1] != target_func:
            trace.append(target_func)

        return " -> ".join(trace) if trace else target_func

    @staticmethod
    def log_function(debug_attr: str = "debug"):
        def decorator(func):
            @wraps(func)
            def wrapper(self, *args, **kwargs):
                if getattr(self, debug_attr, False):
                    trace = DecoratorUtil._get_clean_call_trace(self_obj=self, target_func=func.__name__)
                    self.logger.debug(f"function start: {trace}")
                    result = func(self, *args, **kwargs)
                    self.logger.debug(f"function end: {trace}")
                    return result
                return func(self, *args, **kwargs)
            return wrapper
        return decorator


# In[14]:


class FunctionUtil:
    @staticmethod
    def timestamp_to_string(timestamp):
        """
        Convert timestamp to string format: 'YYYY-MM-DD HH:mm:ss.SSSSSS'
        """
        return timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")

    @staticmethod
    def get_temp_view_name() -> str:
        """
        Generate a unique temporary view name.
        """
        # "-" is not allowed in spark sql
        return f"vw_temp_{str(uuid.uuid4()).replace('-', '_')}"

    @staticmethod
    def string_to_list(value: str):
        """
        Convert a comma-separated string to a list of cleaned keys.
        """
        if not value:
            return []
        return [k.strip() for k in value.split(",") if k.strip()]


# In[15]:


class DeltaTableUtil:
    @staticmethod
    def generate_unique_id(spark: SparkSession, df: DataFrame, keyname: str = "_unique_id", startid: int = 1) -> DataFrame:
        # New schema: unique ID first
        new_schema = StructType([StructField(keyname, LongType(), False)] + df.schema.fields)

        # zipWithUniqueId generates the ID — we put it first to match the schema
        rdd_with_id = df.rdd.zipWithUniqueId().map(lambda x: (x[1],) + tuple(x[0]))

        # Create DataFrame with explicit schema
        df_with_id = spark.createDataFrame(rdd_with_id, schema=new_schema)

        # Offset the ID if needed
        if startid != 0:
            df_with_id = df_with_id.withColumn(keyname, col(keyname) + startid)

        return df_with_id

    @staticmethod
    def run_sql_script(script: str, spark: SparkSession, debug: BooleanType = False):
        # Split by semicolon and remove empty/whitespace-only statements
        statements = [stmt.strip() for stmt in script.split(';') if stmt.strip()]
        
        for stmt in statements:
            if debug:
                print(f"Executing:\n{stmt}\n---")
            try:
                df = spark.sql(stmt)
            except Exception as e:
                raise SyntaxError(f"sql script syntax error: {stmt} - {e}")

            if debug:
                # Only show results if it's a SELECT
                if stmt.strip().lower().startswith("select"):
                    df.show(10, False)    

    @staticmethod
    def column_to_list(df, col_name: str):
        if col_name not in df.columns:
            raise ValueError(f"Column '{col_name}' not found in DataFrame.")

        return [row[col_name] for row in df.select(col_name).collect()]

    @staticmethod
    def get_max_column_value(
        spark: SparkSession,
        table_name: str,
        target_column: str,
        filters: str = None  # e.g., "region = 'US' AND status = 'active'"
    ):
        """
        Returns the maximum value of a column from a Delta table, optionally filtered by an expression.

        :param spark: SparkSession object
        :param table_name: Full Delta table name (e.g., 'my_db.my_table')
        :param target_column: Column to compute max value for
        :param filters: Optional SQL expression string for filtering rows
        :return: The maximum value of the column, or None if the table is empty or no matches
        :raises ValueError: If the target_column does not exist in the table
        """
        try:
            table_full_name = DeltaTableUtil.get_table_full_name(table_name)
            df = spark.read.format("delta").table(table_full_name)

            if target_column not in df.columns:
                msg = f"Column '{target_column}' not found in table '{table_full_name}'."
                raise ValueError(msg)

            if filters:
                df = df.filter(expr(filters))

            result = df.selectExpr(f"max({target_column}) as max_val").collect()
            return result[0]["max_val"] if result else None

        except Exception as e:
            raise

    @staticmethod
    def safe_drop_columns(df, cols_to_drop):
        existing_cols = [col for col in cols_to_drop if col in df.columns]
        return df.drop(*existing_cols)

    @staticmethod
    def combine_columns_as_dict(df: DataFrame, columns: list[str], new_col_name: str = "combined") -> DataFrame:
        """
        Combine specified columns into a dictionary column where keys are column names and values are row values.

        :param df: Input Spark DataFrame
        :param columns: List of column names to include in the dictionary
        :param new_col_name: Name of the resulting dictionary column (default is 'combined')
        :return: DataFrame with an added MapType column
        """
        kv_pairs = list(chain.from_iterable((lit(c), col(c)) for c in columns))
        return df.withColumn(new_col_name, create_map(*kv_pairs))

    @staticmethod
    def ensure_system_columns(
        spark: SparkSession,
        table_name: str,
        extra_columns: dict = None 
    ):
        """
        Ensures that the specified Delta table has the required system columns.

        Args:
            spark (SparkSession): Spark session object.
            table_name (str): Qualified Delta table name (e.g. 'schema.table').
            corrupt_column (str): Name of the corrupt record column. Defaults to '_corrupt_record'.
            rescued_column (str): Name of the rescued data column. Defaults to '_rescued_data'.

        Returns:
            bool: True if the table has the required system columns, False otherwise.
        """

        # ensure table existence
        table_full_name = DeltaTableUtil.get_table_full_name(table_name)
        try:
            spark.sql(f"DESCRIBE TABLE {table_full_name}")
        except Exception as e:
           raise ValueError(f"Table '{table_full_name}' does not exist.")
       
        extra_columns = extra_columns or {}
        required_columns = extra_columns | {
            "_source_name": StringType(),
            "_source_timestamp": TimestampType(),
            "_record_id": StringType(),
            "_record_timestamp": TimestampType(),
            "_record_deleted": BooleanType()
        }

        # Get current table schema
        existing_columns = {field.name for field in spark.table(table_full_name).schema.fields}

        # Identify missing columns
        missing_columns = {
            col: dtype for col, dtype in required_columns.items() if col not in existing_columns
        }

        if missing_columns:
            try:
                # Add missing columns via SQL
                for col, dtype in missing_columns.items():
                    ddl = f"ALTER TABLE {table_full_name} ADD COLUMNS ({col} {dtype.simpleString()})"
                    spark.sql(ddl)
            except Exception as e:
                raise Exception(f"Error adding missing columns to table '{table_full_name}': {e}")

    @staticmethod
    def get_join_condition(alias_df: str, alias_table: str, primary_keys: str) -> str:
        """
        Constructs a join condition string between two aliases using primary key columns.
        Accepts primary keys as a comma-separated string and splits it internally.

        :param alias_df: Alias of the DataFrame
        :param alias_table: Alias of the table
        :param primary_keys: Comma-separated primary key column names string
        :return: Join condition string
        """
        # Split primary_keys string into list, trimming whitespace
        keys_list = [k.strip() for k in primary_keys.split(",")]

        conditions = [f"{alias_df}.{k} = {alias_table}.{k}" for k in keys_list]
        return reduce(lambda x, y: f"{x} and {y}", conditions)

    @staticmethod
    def get_generated_columns(spark: SparkSession, table_name: str) -> list:
        """
        Extracts a list of generated columns from the given Delta table.

        :param spark: SparkSession object
        :param table_name: QualifiedName of the Delta table
        :return: List of column names that are generated always as
        """
        table_full_name = DeltaTableUtil.get_table_full_name(table_name)
        ddl = spark.sql(f"SHOW CREATE TABLE {table_full_name}").collect()[0][0]
        gen_col_pattern = re.compile(r"generated\s+always\s+as", re.IGNORECASE)
        generated_columns = []

        for line in ddl.splitlines():
            if gen_col_pattern.search(line):
                col_name = line.strip().split()[0].strip("`")
                generated_columns.append(col_name)

        return generated_columns

    @staticmethod
    def match_columns(spark: SparkSession, df: DataFrame, sink_name: str) -> DataFrame:
        """
        Aligns, casts, and validates the DataFrame's columns against the target Delta table,
        excluding generated columns. Reorders columns and attempts to cast them to match
        the target schema.

        :param df: Source DataFrame
        :param sink_name: Fully qualified Delta table name (e.g., 'db.bronze.table')
        :return: DataFrame with aligned and casted columns
        :raises ValueError: If columns do not match or cannot be cast
        """
        # import again since the function is executed in a write stream
        from pyspark.sql import functions as F

        source_columns = set(df.columns)
        target_df = spark.table(sink_name)

        # Get generated columns to exclude from comparison
        generated_columns = DeltaTableUtil.get_generated_columns(spark, sink_name)

        # Build target schema excluding generated columns
        target_schema = [
            field
            for field in target_df.schema.fields
            if field.name not in generated_columns
        ]
        target_column_names = [field.name for field in target_schema]
        target_column_types = {field.name: field.dataType for field in target_schema}

        # Validate source and target columns (as sets, ignoring order)
        if set(target_column_names) != source_columns:
            error_message = (
                f"Schema mismatch for table '{sink_name}'.\n"
                f"Expected columns (excluding generated): {sorted(target_column_names)}\n"
                f"Provided DataFrame columns: {sorted(source_columns)}"
            )
            raise ValueError(error_message)

        # Attempt to cast source DataFrame columns to match target schema
        casted_columns = []
        for col_name in target_column_names:
            target_type: DataType = target_column_types[col_name]
            try:
                casted_columns.append(F.col(col_name).cast(target_type).alias(col_name))
            except Exception as e:
                error_message = f"Failed to cast column '{col_name}' to type '{target_type.simpleString()}': {e}"
                raise ValueError(error_message)

        # Return reordered and casted DataFrame
        return df.select(casted_columns)

    @staticmethod
    def validate_columns(spark: SparkSession, df: DataFrame, sink_name: str):
        """
        Ensure all source columns in the DataFrame exist in the sink table schema,
        excluding any generated columns.

        :param df: DataFrame to validate
        :param sink_name: Fully qualified Delta table name
        :raises ValueError: If any source column does not exist in sink
        """
        source_columns = set(df.columns)
        sink_df = spark.table(sink_name)
        generated_columns = DeltaTableUtil.get_generated_columns(spark, sink_name)
        sink_columns = {
            field.name
            for field in sink_df.schema.fields
            if field.name not in generated_columns
        }

        missing_columns = source_columns - sink_columns
        if missing_columns:
            error_message = (
                f"Update mode validation failed: Source DataFrame contains columns not present in sink table '{sink_name}'.\n"
                f"Missing in sink: {sorted(missing_columns)}\n"
                f"Sink columns (excluding generated): {sorted(sink_columns)}"
            )
            raise ValueError(error_message)

    @staticmethod
    def deduplicate(df: DataFrame, primary_keys: list, deduplication_columns: str) -> DataFrame:
        """
        Deduplicates the DataFrame by keeping only one record per primary key,
        using composite deduplication columns with optional sort direction.

        :param df: Input Spark DataFrame
        :param primary_key: Comma-separated list of primary key columns (e.g., "id,sub_id")
        :param deduplication_columns: String defining columns and sort directions
            (e.g., "event_time desc, event_sequence", defaults to asc if not specified)
        :return: Deduplicated DataFrame
        """
        if not deduplication_columns:
            return df

        if not primary_keys or len(primary_keys) == 0:
            message = "primary key is required"
            raise ValueError(message)

        try:
            # Parse deduplication column string
            sort_exprs = []
            for entry in deduplication_columns.split(","):
                parts = entry.strip().split()
                if len(parts) == 1:
                    col_name, direction = parts[0], "asc"
                elif len(parts) == 2:
                    col_name, direction = parts[0], parts[1].lower()
                else:
                    raise ValueError(
                        f"Invalid format for deduplication column: '{entry.strip()}'"
                    )

                if direction == "desc":
                    sort_exprs.append(col(col_name).desc())
                elif direction == "asc":
                    sort_exprs.append(col(col_name).asc())
                else:
                    raise ValueError(
                        f"Unsupported sort order '{direction}' for column '{col_name}'"
                    )

            window_spec = Window.partitionBy(*primary_keys).orderBy(*sort_exprs)
            df_deduplicated = (
                df.withColumn("_row_number", row_number().over(window_spec))
                .filter(col("_row_number") == 1)
                .drop("_row_number")
            )

        except Exception as e:
            message = f"Error during deduplication: {e}"
            raise Exception(message)

        return df_deduplicated
    
    @staticmethod
    def columns_exist(df, columns, match_all=True):
        """
        Check if specified columns exist in a DataFrame.

        Parameters:
            df (DataFrame): The PySpark DataFrame.
            columns (List[str]): List of column names to check.
            match_all (bool): If True, checks that all columns exist.
                            If False, checks that at least one exists.

        Returns:
            bool: True if condition met, False otherwise.
        """
        df_columns = set(df.columns)
        target_columns = set(columns)

        if match_all:
            return target_columns.issubset(df_columns)
        else:
            return not df_columns.isdisjoint(target_columns)

    @staticmethod
    def get_table_full_path(table_name: str) -> str:
        table_full_path = f"Tables/{table_name.replace('.', '/')}"
        return table_full_path


# In[16]:


@DecoratorUtil.add_logger()
class FileUtil:

    def __init__(self, debug = False):
        self.debug = debug

    # archive the files
    @DecoratorUtil.log_function()
    def archive_files(files: list):
        for file in files:
            if not notebookutils.fs.exists(file):
                raise FileNotFoundError(f"file does not exist : {file}")

            # get the destination file path
            file_archive = file.replace(
                Environment.source["source_data_root_path"], 
                Environment.source["source_data_root_path_archived"]
            )
            file_archive_path = posixpath.dirname(file_archive)
            notebookutils.fs.mkdirs(file_archive_path)

            # move the file
            if notebookutils.fs.exists(file_archive):
                filename = posixpath.basename(file_archive)
                name, ext = os.path.splitext(filename)
                unique_name = f"{name}_{uuid.uuid4()}.{ext}"
                file_archive = posixpath.join(file_archive_path, unique_name)

            print(file, file_archive)
            notebookutils.fs.mv(file, file_archive)

    # delete the files
    @DecoratorUtil.log_function()
    def delete_files(files: list):
        for file in files:
            if not notebookutils.fs.exists(file):
                raise FileNotFoundError("file does not exist : {file}")
            
            # delete the file
            notebookutils.fs.rm(file)

    # get all files in the root path and the sub folders 
    # file path or file name must include date with YYYMMDD format
    def get_files_recursive(self, file_path, source_files):
        list_files = notebookutils.fs.ls(file_path)
        for file_info in list_files: 
            if file_info.isDir:
                # if it is a folder, get the files
                self.get_files_recursive(file_info.path, source_files)
            elif file_info.isFile:
                source_files.append({"file_name": file_info.name, 
                                    "file_path": file_info.path, 
                                    "file_modification_timestamp": mdt.datetime.fromtimestamp(file_info.modifyTime / 1000), 
                                    "file_size": file_info.size})
    # function end: get_files_recursive

    @DecoratorUtil.log_function()
    def get_files(self, file_path, file_name_regex):
        if self.debug:
            self.logger.debug(f"file_path: {file_path}")
            self.logger.debug(f"file_name_regex: {file_name_regex}")

        
        source_files_regex = []
        file_path_list = file_path.split(",")
        for file_path_i in file_path_list:
            source_files = []
            file_path_i_trimmed = file_path_i.strip()
            self.get_files_recursive(file_path_i_trimmed, source_files)
            if self.debug:
                self.logger.debug(f"source_files: {len(source_files)}")
                #self.logger.debug(f"source_files: {source_files}\n")

        
            if not (file_name_regex is None or file_name_regex == ""):
                for file_item in source_files[:]:  
                    # only get the files which match the regex 
                    if re.search(file_name_regex, file_item["file_name"]):
                        # get relative file path
                        file_item_path = re.search(f"{file_path_i_trimmed}.*", file_item["file_path"]).group()
                        # extract YYYYMMDD from file path from left to right
                        file_item_date_match = re.search(r"\d{4}\d{2}\d{2}", file_item_path)
                        if file_item_date_match:
                            file_item_date = file_item_date_match.group()
                            file_item_date = f"{file_item_date[0:4]}-{file_item_date[4:6]}-{file_item_date[6:8]}"
                        else:
                            file_item_date = "1900-01-01" 
                        source_files_regex.append({"file_name": file_item["file_name"],
                                                    "file_path": file_item_path,
                                                    "file_modification_timestamp": file_item["file_modification_timestamp"],
                                                    "file_size": file_item["file_size"],
                                                    "file_date": file_item_date
                                                    }
                                                )

        if self.debug:
            self.logger.debug(f"source_files_regex: {len(source_files_regex)}")
        
        return source_files_regex
    # function end: get_files

    @DecoratorUtil.log_function()
    def posi_file_rename(self, file_path, file_name_regex):
        # rename the posi files
        #file_path = "Files/pocdata/live/posi/"
        #file_name_regex_list = ["^(ADJUSTS)(\.DBF)$", "^(CHKHDR)(\.DBF)$", "^(CHKITEMS)(\.DBF)$", "^(FCOSTN)(\.DBF)$", "^(JOURNAL)(\.DBF)$"]
        #for file_name_regex in file_name_regex_list:
        fileutil = FileUtil(False)
        source_files = fileutil.get_files(file_path, file_name_regex)

        for file_dict in source_files:
            file_path_old = file_dict['file_path']
            
            # extract YYYYMMDD from path
            file_date_str = re.search(r"/\d{2}-\d{2}-\d{2}/", file_path_old).group()
            file_date_list = file_date_str.strip("/").split("-")
            file_date = f"20{file_date_list[2]}{file_date_list[0]}{file_date_list[1]}"
            #self.logger.debug(f"file_date: {file_date}")
            file_store_str = re.search(r"/\d{4}/", file_path_old).group()
            file_store =  file_store_str.strip("/")
            #self.logger.debug(f"file_store: {file_store}")
            file_name_new =  f"{file_date}_{file_store}_{file_dict['file_name']}"
            file_path_new = re.sub(file_name_regex.strip("^"), file_name_new, file_path_old)

            file_dict['file_path'] = file_path_new

            if self.debug:
                self.logger.debug(f"file_rename: {file_path_old} -> {file_path_new}")
            notebookutils.fs.mv(file_path_old, file_path_new)



# In[17]:


@DecoratorUtil.add_logger()
class TableUtil:

    def __init__(self, table_name, spark, debug = False):

        self.table_name = table_name
        self.spark = spark
        self.debug = debug
        
        if debug:
            self.logger.debug(f"table_name: {table_name}")

        
        if not spark.catalog.tableExists(table_name):
            error_msg = f"'{table_name}' does not exist"
            self.logger.error(error_msg)
            raise Exception(error_msg)


    @DecoratorUtil.log_function()
    def clean_table(self):
        sql_statement = f"delete from {self.table_name};"
        self.spark.sql(sql_statement)
        sql_statement = f"alter table {self.table_name} unset TBLPROPERTIES('mdd.source.primary', 'mdd.source.secondary', 'mdd.patcher.source', 'mdd.patcher.timestamp', 'mdd.validator.expectation', 'mdd.validator.timestamp');"
        self.spark.sql(sql_statement)
        sql_statement = f"delete from mdd.etl_job_files where table_name = '{self.table_name}';"
        self.spark.sql(sql_statement)

    @DecoratorUtil.log_function()
    def get_table_property_dict_value(self, property_name, property_key, is_timestamp = False):
        table_property_dict = self.get_table_properties()
        if self.debug:
            self.logger.debug(f"table_property_dict: {table_property_dict}")
            self.logger.debug(f"property_key: {property_key}")

        property_dict = {}
        if property_name in table_property_dict:
            property_str = table_property_dict[property_name]
            property_dict = json.loads(property_str)
        
        if self.debug:
            self.logger.debug(f"property_dict: {property_dict}")
        
        property_value = None
        if property_key in property_dict:
            property_value_str = property_dict[property_key]
            if self.debug:
                self.logger.debug(f"property_value_str: {property_value_str}")
            
            if is_timestamp:
                property_value = mdt.datetime.strptime(property_value_str, "%Y-%m-%d, %H:%M:%S.%f") 
            else:
                property_value = property_value_str

        if self.debug:
            self.logger.debug(f"property_value: {property_value}")

        return property_value

    @DecoratorUtil.log_function()
    def set_table_property_list(self, property_name, property_values):
        table_property_dict = self.get_table_properties()
        if self.debug:
            self.logger.debug(f"table_property_dict: {table_property_dict}")
            self.logger.debug(f"property_values: {property_values}")

        property_list = []
        if property_name in table_property_dict:
            property_str = table_property_dict[property_name]
            property_list = [column.strip() for column in property_str.split(",")]
        if self.debug:
            self.logger.debug(f"property_list: {property_list}")
        
        if property_values is not None:
            if type(property_values) == str:
                property_values_list = [column.strip() for column in property_values.split(",")]
            else:
                property_values_list = property_values

            final_list = list(set(property_list) | set(property_values_list))
            final_list.sort()
            property_str = ", ".join([str(t) for t in final_list])

            property_set_sql = f"alter table {self.table_name} set TBLPROPERTIES ({property_name} = '{property_str}')"
            if self.debug:
                self.logger.debug(f"final_list: {final_list}")
                self.logger.debug(f"property_str: {property_str}")
                self.logger.debug(f"property_set_sql: {property_set_sql}")

            self.spark.sql(property_set_sql)

    @DecoratorUtil.log_function()
    def set_table_property_dict(self, property_name, property_key, property_value):
        table_property_dict = self.get_table_properties()
        if self.debug:
            self.logger.debug(f"table_property_dict: {table_property_dict}")
            self.logger.debug(f"property_key: {property_key}")
            self.logger.debug(f"property_value: {property_value}")

        property_dict = {}
        if property_name in table_property_dict:
            property_str = table_property_dict[property_name]
            property_dict = json.loads(property_str)
            
        if self.debug:
            self.logger.debug(f"property_dict: {property_dict}")
        
        property_dict[property_key] = property_value
        property_str = json.dumps(property_dict)
        property_set_sql = f"alter table {self.table_name} set TBLPROPERTIES ({property_name} = '{property_str}')"
        if self.debug:
            self.logger.debug(f"property_dict: {property_dict}")
            self.logger.debug(f"property_str: {property_str}")
            self.logger.debug(f"property_set_sql: {property_set_sql}")

        self.spark.sql(property_set_sql)

    @DecoratorUtil.log_function()
    def get_table_properties(self):
        table_property_df = self.spark.sql(f"SHOW TBLPROPERTIES {self.table_name}")
        table_property_dict = {row["key"]: row["value"] for row in table_property_df.collect()}
        
        if self.debug:
            self.logger.debug(f"table_property_dict: {table_property_dict}")
        
        return table_property_dict
    
    @DecoratorUtil.log_function()
    def get_table_merge_info(self, timestamp_from, timestamp_to):
        table_history_df = self.spark.sql(f"describe history {self.table_name}")
        table_history_df = table_history_df.filter((table_history_df.operation == "MERGE") & (table_history_df.timestamp > timestamp_from ) & (table_history_df.timestamp < timestamp_to)) 
        table_history_df = table_history_df.sort(table_history_df.timestamp.desc()).select("operationMetrics")

        merge_dict = {}
        if not table_history_df.isEmpty():
            merge_dict = table_history_df.first()[0]

        if self.debug:
            self.logger.debug(f"merge_dict: {merge_dict}")
        
        return merge_dict

    @DecoratorUtil.log_function()
    def get_table_history(self):
        table_history_df = self.spark.sql(f"describe history {self.table_name}")
        table_history_version_min = 0
        table_history_version_max = 0
        table_history_version_agg_df = table_history_df.agg(min(table_history_df.version).alias("version_min"), max(table_history_df.version).alias("version_min"))
        if not table_history_version_agg_df.isEmpty():
            table_history_version_min = table_history_version_agg_df.first()[0]
            table_history_version_max = table_history_version_agg_df.first()[1]
        
        table_history_version_cdf = 0
        table_property_dict = self.get_table_properties()
        if table_property_dict["delta.enableChangeDataFeed"] == "true":   
            table_history_properties_df = table_history_df.select(table_history_df.version, explode(table_history_df.operationParameters)).filter("key = 'properties'")
            table_history_cdf_df = table_history_properties_df.filter(table_history_properties_df.value.contains("\"delta.enableChangeDataFeed\":\"true\"")) \
                                                    .select(max(table_history_properties_df.version))
            if not table_history_cdf_df.isEmpty():
                table_history_version_cdf = table_history_cdf_df.first()[0]
        
        # get the max timestamp of the records
        table_timestamp_df = self.spark.sql(f"select max(_record_timestamp) from {self.table_name}")
        table_history_timestamp_max = None
        if not table_timestamp_df.isEmpty():
            table_history_timestamp_max = table_timestamp_df.first()[0]

        table_history_dict = {
                                "table_history_version_min": table_history_version_min, 
                                "table_history_version_max": table_history_version_max,
                                "table_history_version_cdf": table_history_version_cdf,
                                "table_history_timestamp_max": table_history_timestamp_max
                            }

        if self.debug:
            self.logger.debug(f"table_history_dict: {table_history_dict}")

        return table_history_dict


# In[18]:


class JobUtil:
    @staticmethod
    def etl_job_update(
        lakehouse_guid,
        job_run_id,
        job_name,
        job_start_timestamp,
        job_end_timestamp,
        job_status,
        error_message
    ):
        path = f"/{lakehouse_guid}/Tables/mdd/etl_job"
        log_timestamp = mdt.datetime.utcnow()

        data = [
            (
                job_run_id,
                job_name,
                job_start_timestamp,
                job_end_timestamp,
                job_status,
                error_message,
                log_timestamp
            )
        ]
        spark_session = SparkSession.builder.getOrCreate()
        df = spark_session.createDataFrame(
            data,
            "job_run_id string, job_name string, job_start_timestamp timestamp, job_end_timestamp timestamp, job_status string, error_message string, log_timestamp timestamp",
        )
        dt = DeltaTable.forPath(spark_session, path)
        (
            dt.alias("t")
            .merge(
                df.alias("s"),
                f"s.job_run_id = t.job_run_id and s.job_name = t.job_name and t.job_name = '{job_name}'",
            )
            .whenNotMatchedInsertAll()
            .whenMatchedUpdate(
                set={
                    "job_end_timestamp": "s.job_end_timestamp",
                    "job_status": "s.job_status",
                    "error_message": "s.error_message",
                    "log_timestamp": "s.log_timestamp"
                }
            )
            .execute()
        )

    @staticmethod
    def etl_job_tasks_update(
        lakehouse_guid,
        task_run_id,
        task_name,
        task_start_timestamp,
        task_end_timestamp,
        task_status,
        parent_task_run_id,
        job_run_id,
        error_message
    ):
        path = f"/{lakehouse_guid}/Tables/mdd/etl_job_tasks"
        log_timestamp = mdt.datetime.utcnow()

        data = [
            (
                task_run_id,
                task_name,
                task_start_timestamp,
                task_end_timestamp,
                task_status,
                parent_task_run_id,
                job_run_id,
                error_message,
                log_timestamp
            )
        ]
        spark_session = SparkSession.builder.getOrCreate()
        df = spark_session.createDataFrame(
            data,
            "task_run_id string, task_name string, task_start_timestamp timestamp, task_end_timestamp timestamp, task_status string, parent_task_run_id string, job_run_id string, error_message string, log_timestamp timestamp",
        )
        dt = DeltaTable.forPath(spark_session, path)
        (
            dt.alias("t")
            .merge(
                df.alias("s"),
                f"s.task_run_id = t.task_run_id and s.task_name = t.task_name and t.task_name = '{task_name}'",
            )
            .whenNotMatchedInsertAll()
            .whenMatchedUpdate(
                set={
                    "task_end_timestamp": "s.task_end_timestamp",
                    "task_status": "s.task_status",
                    "error_message": "s.error_message",
                    "log_timestamp": "s.log_timestamp"
                }
            )
            .execute()
        )

    @staticmethod
    def etl_job_files_update(
        file_run_id,
        file_name,
        file_timestamp,
        file_date,
        file_path,
        table_name,
        data_sync_mode,
        data_write_mode,
        rows_read,
        rows_onboarded,
        task_run_id,
        job_run_id
    ):
        log_timestamp = mdt.datetime.utcnow()

        data = [
            (
                file_run_id,
                file_name,
                file_timestamp,
                file_date,
                file_path,
                file_rows,
                table_name,
                data_sync_mode,
                data_write_mode,
                rows_read,
                rows_onboarded,
                task_run_id,
                job_run_id,
                log_timestamp
            )
        ]
        spark_session = SparkSession.builder.getOrCreate()
        df = spark_session.createDataFrame(
            data,
            "file_run_id string, file_name string, file_timestamp timestamp, file_date string, file_path string, table_name string, data_sync_mode string, data_write_mode string, rows_read long, rows_onboarded long, task_run_id string , job_run_id string , log_timestamp timestamp",
        )
        df.write.mode("append").saveAsTable("mdd.etl_job_files")
        
    @staticmethod
    def etl_job_tables_update(    
    table_run_id              
    ,table_name               
    ,data_sync_mode  
    ,data_write_mode         
    ,source_table_name        
    ,source_table_timestamp   
    ,source_table_cdfversion   
    ,rows_read                
    ,batches                  
    ,batch                    
    ,rows_in_batch            
    ,rows_inserted            
    ,rows_updated             
    ,rows_deleted             
    ,read_start_timestamp     
    ,read_end_timestamp       
    ,transform_start_timestamp
    ,transform_end_timestamp  
    ,write_start_timestamp    
    ,write_end_timestamp  
    ,secondary_tables    
    ,task_run_id              
    ,job_run_id               
    ,log_timestamp            
            
    ):
        data = [(    
            table_run_id              
            ,table_name               
            ,data_sync_mode  
            ,data_write_mode         
            ,source_table_name        
            ,source_table_timestamp   
            ,source_table_cdfversion   
            ,rows_read                
            ,batches                  
            ,batch                    
            ,rows_in_batch            
            ,rows_inserted            
            ,rows_updated             
            ,rows_deleted             
            ,read_start_timestamp     
            ,read_end_timestamp       
            ,transform_start_timestamp
            ,transform_end_timestamp  
            ,write_start_timestamp    
            ,write_end_timestamp   
            ,secondary_tables   
            ,task_run_id              
            ,job_run_id               
            ,log_timestamp            
            
        )]

        schema = """
        table_run_id                   string
        ,table_name                    string
        ,data_sync_mode                string
        ,data_write_mode               string
        ,source_table_name             string
        ,source_table_timestamp        timestamp
        ,source_table_cdfversion       long
        ,rows_read                     long
        ,batches                       long
        ,batch                         string
        ,rows_in_batch                 long
        ,rows_inserted                 long
        ,rows_updated                  long
        ,rows_deleted                  long
        ,read_start_timestamp          timestamp
        ,read_end_timestamp            timestamp
        ,transform_start_timestamp     timestamp
        ,transform_end_timestamp       timestamp
        ,write_start_timestamp         timestamp
        ,write_end_timestamp           timestamp
        ,secondary_tables              string
        ,task_run_id                   string
        ,job_run_id                    string
        ,log_timestamp                 timestamp
        """

        spark_session = SparkSession.builder.getOrCreate()

        df = spark_session.createDataFrame(data, schema)
        df.write.mode("append").saveAsTable("mdd.etl_job_tables")

    @staticmethod
    def table_validation_update(
        table_name: str
        ,df_summary: DataFrame
        ,validation_run_id: str = "validation_123"
        ,task_run_id: str = "task_123"
        ,job_run_id: str = "job_123"
    ):
        df = (df_summary.withColumn("table_name", lit(table_name))
            .withColumn("validation_run_id", lit(validation_run_id))
            .withColumn("task_run_id", lit(task_run_id))
            .withColumn("job_run_id", lit(job_run_id))
            .withColumn("log_timestamp", lit(mdt.datetime.utcnow()))
        ).select(
            "validation_run_id"
            ,"table_name"
            ,"source"
            ,"source_count"
            ,"expectation_name"
            ,"expectation_condition"
            ,"expectation_action"
            ,"expectation_passed"
            ,"expectation_failedcount"
            ,"expectation_start_timestamp"
            ,"expectation_end_timestamp"
            ,"task_run_id"
            ,"job_run_id"
            ,"log_timestamp"
        )
        df.write.mode("append").saveAsTable("mdd.table_validation")

    @staticmethod
    def etl_job_tables_get_lasttimestamp(table_name: str) -> TimestampType:
        spark_session = SparkSession.builder.getOrCreate()

        df = (
            spark_session.table("mdd.etl_job_tables")
                .filter(col("table_name") == table_name)
                .orderBy(desc("log_timestamp"))
                .limit(1)
                .select("source_table_timestamp")
        )

        last_timestamp = None
        if not df.isEmpty():
            last_timestamp = df.first()[0]

        return last_timestamp

    @staticmethod
    def etl_job_tables_get_lastcdfversion(table_name: str) -> LongType:
        spark_session = SparkSession.builder.getOrCreate()

        df = (
            spark_session.table("mdd.etl_job_tables")
                .filter(col("table_name") == table_name)
                .orderBy(desc("log_timestamp"))
                .limit(1)
                .select("source_table_cdfversion")
        )

        last_cdfversion = None
        if not df.isEmpty():
            last_cdfversion = df.first()[0]

        return last_cdfversion

