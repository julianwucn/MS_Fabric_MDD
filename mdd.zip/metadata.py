#!/usr/bin/env python
# coding: utf-8

# ## metadata
# 
# New notebook

# In[ ]:


import yaml
import json
import datetime as mdt
import pathlib
import logging

from env.mdd.environment import *
from env.mdd.mddutils import *


# In[ ]:


class Metadata:

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")
            logger.debug(f"metadata_yml: {metadata_yml}")

        self.logger = logger
        self.debug = debug

        # get relatvie path
        i = metadata_yml.rfind('/')
        self.metadata_yml_path =  metadata_yml[0: i]
        
        # open the yaml file
        metadata_yml_file = f"{Environment.root_path_metadata}{metadata_yml}"
        if debug:
            logger.debug(f"metadata_yml_file: {metadata_yml_file}")
        try:    
            with open(metadata_yml_file, mode='rt') as yf:
                metadata = yaml.safe_load(yf)
                self.metadata = metadata
        except Exception as err:
            msg = f"YAML file error: {metadata_yml_file}"
            logger.error(err)
            raise Exception(msg)
        
        # get the configuraitons from the yaml file
        self.id = metadata["id"]
        self.type = metadata["type"]
        self.version = metadata["version"]
        self.author = metadata["author"]
        self.comment = metadata["comment"]

        if debug:
            logger.debug("metadata header")
            logger.debug(f"id: {self.id}")
            logger.debug(f"version: {self.version}")
            logger.debug(f"author: {self.author}")
            logger.debug(f"comment: {self.comment}")
            logger.debug(f"function end: {function_name}")
    # function end: init

    def to_json(self):
        function_name = "to_json"
        if debug:
            logger.debug(f"function begin: {function_name}")

        metadata_json = json.dumps(self.metadata)
        if debug:
            logger.debug(f"metadata_json: {metadata_json}")
            logger.debug(f"function end: {function_name}")
            
        return metadata_json
    # function end: to_json
        


# In[ ]:


class Metadata_Lander(Metadata):

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")
            logger.debug(f"metadata_yml: {metadata_yml}")

        super().__init__(metadata_yml, logger, debug)

        metadata = self.metadata

        self.source_server_options = metadata["source_server_options"]
        self.data_landers = metadata["data_landers"]

        if debug:
            logger.debug("metadata detail:")
            logger.debug(f"source_server_options: {self.source_server_options}")
            logger.debug(f"data_landers: {self.data_landers}")
            logger.debug(f"function end: {function_name}")
    # function end: init


# In[ ]:


class Metadata_Patcher(Metadata):

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")
            logger.debug(f"metadata_yml: {metadata_yml}")

        super().__init__(metadata_yml, logger, debug)

        metadata = self.metadata
        self.patcher = metadata["patcher"]

        if debug:
            logger.debug("metadata detail:")
            logger.debug(f"patcher: {self.patcher}")
            logger.debug(f"function end: {function_name}")
    # function end: init


# In[ ]:


class Metadata_Validator(Metadata):

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")

        super().__init__(metadata_yml, logger, debug)

        if debug:
            logger.debug(f"function end: {function_name}")
    # function end: init


# In[ ]:


class Metadata_Dataflow(Metadata):
    def __init__(self, metadata_yml, logger, debug = False):
        super().__init__(metadata_yml, logger, debug)

        metadata = self.metadata
        self.dataflow_type = metadata["dataflow_type"]


# In[ ]:


class Metadata_Onboarding_Dataflow(Metadata):

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        
        if debug:
            logger.debug(f"function begin: {function_name}")

        super().__init__(metadata_yml, logger, debug)

        metadata = self.metadata
        
        # get the configuraitons from the yaml file
        self.dataflow_type = metadata["dataflow_type"]

        if self.dataflow_type.lower() not in ("onboard", "onboarding"):
            raise ValueError(f"Incorrect dataflow type {self.dataflow_type}")

        # reader
        self.source_data_format = metadata["reader"]["source_data_format"]
        self.source_data_relative_path = metadata["reader"]["source_data_relative_path"]
        self.source_file_name_regex = metadata["reader"]["source_file_name_regex"]
        self.source_file_cleanup = metadata["reader"]["source_file_cleanup"]
        self.Source_data_read_options = metadata["reader"]["Source_data_read_options"]
        self.source_data_schema = metadata["reader"]["source_data_schema"]

        # writer
        self.destination_table_name = metadata["writer"]["destination_table_name"]
        self.destination_projected_sql = metadata["writer"]["destination_projected_sql"]
        self.destination_write_mode = metadata["writer"]["destination_write_mode"]
        self.destination_write_options = metadata["writer"]["destination_write_options"]
        self.destination_primarykey = FunctionUtil.string_to_list(metadata["writer"]["destination_primarykey"])
        self.destination_deduplication_expr = metadata["writer"]["destination_deduplication_expr"]
        self.destination_watermark_column = metadata["writer"]["destination_watermark_column"]
        self.destination_update_changes_only = metadata["writer"]["destination_update_changes_only"]

        

        self.destination_write_prescript = metadata["writer"]["destination_write_prescript"]
        if self.destination_write_prescript:
            i = self.destination_write_prescript.rfind('/')
            if i < 0:
                self.destination_write_prescript = f"{self.metadata_yml_path}/script/{self.destination_write_prescript}"

        self.destination_write_postscript = metadata["writer"]["destination_write_postscript"]
        if self.destination_write_postscript:
            i = self.destination_write_postscript.rfind('/')
            if i < 0:
                self.destination_write_postscript = f"{self.metadata_yml_path}/script/{self.destination_write_postscript}"

        # validator
        self.validator = metadata["validator"]
        # set default path to /validate/
        if self.validator is not None and self.validator != "":
            i = self.validator.rfind('/')
            if i < 0:
                self.validator = f"{self.metadata_yml_path}/validate/{self.validator}"
                
        if debug:
            logger.debug("metadata detail:")
            logger.debug(f"source_data_format: {self.source_data_format}")
            logger.debug(f"source_data_relative_path: {self.source_data_relative_path}")
            logger.debug(f"source_file_name_regex: {self.source_file_name_regex}")
            logger.debug(f"Source_data_read_options: {self.Source_data_read_options}")
            logger.debug(f"source_data_schema: {self.source_data_schema}")
            logger.debug(f"destination_table_name: {self.destination_table_name}")
            logger.debug(f"destination_projected_sql: {self.destination_projected_sql}")
            logger.debug(f"destination_write_mode: {self.destination_write_mode}")
            logger.debug(f"destination_write_options: {self.destination_write_options}")
            logger.debug(f"validator: {self.validator}")
            logger.debug(f"function end: {function_name}")
    # function end: init


# In[ ]:


class Metadata_Transform_Dataflow(Metadata):

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        
        if debug:
            logger.debug(f"function begin: {function_name}")

        super().__init__(metadata_yml, logger, debug)

        metadata = self.metadata
        
        # get the configuraitons from the yaml file
        self.dataflow_type = metadata["dataflow_type"]
        if self.dataflow_type.lower() not in ("transform", "trasnforming", "transformation", "load", "loading"):
            raise ValueError(f"Incorrect dataflow type {self.dataflow_type}")
        
        # reader
        self.source_table_name = metadata["reader"]["source_table_name"]
        self.source_primarykey = metadata["reader"]["source_primarykey"]

        # writer
        self.destination_table_name = metadata["writer"]["destination_table_name"]
        self.destination_projected_sql = metadata["writer"]["destination_projected_sql"]
        self.destination_write_mode = metadata["writer"]["destination_write_mode"]
        self.destination_primarykey = metadata["writer"]["destination_primarykey"]
        self.destination_deduplication_expr = metadata["writer"]["destination_deduplication_expr"]
        self.destination_watermark_column = metadata["writer"]["destination_watermark_column"]
        self.destination_update_changes_only = metadata["writer"]["destination_update_changes_only"]
        self.destination_write_options = metadata["writer"]["destination_write_options"]

        self.destination_write_prescript = metadata["writer"]["destination_write_prescript"]
        if self.destination_write_prescript:
            i = self.destination_write_prescript.rfind('/')
            if i < 0:
                self.destination_write_prescript = f"{self.metadata_yml_path}/script/{self.destination_write_prescript}"

        self.destination_write_postscript = metadata["writer"]["destination_write_postscript"]
        if self.destination_write_postscript:
            i = self.destination_write_postscript.rfind('/')
            if i < 0:
                self.destination_write_postscript = f"{self.metadata_yml_path}/script/{self.destination_write_postscript}"
                
        # transformer
        self.transformer = metadata["transformer"]

        # validator
        self.validator = metadata["validator"]
        # set default path to /validate/
        if self.validator is not None and self.validator != "":
            i = self.validator.rfind('/')
            if i < 0:
                self.validator = f"{self.metadata_yml_path}/validate/{self.validator}"

        # patcher
        self.patcher = metadata["patcher"]
        # set default path to /validate/
        if self.patcher is not None and self.patcher != "":
            i = self.patcher.rfind('/')
            if i < 0:
                self.patcher = f"{self.metadata_yml_path}/patch/{self.patcher}"

        if debug:
            logger.debug("metadata detail:")
            logger.debug(f"source_table_name: {self.source_table_name}")
            logger.debug(f"destination_table_name: {self.destination_table_name}")
            logger.debug(f"destination_projected_sql: {self.destination_projected_sql}")
            logger.debug(f"destination_write_mode: {self.destination_write_mode}")
            logger.debug(f"destination_write_options: {self.destination_write_options}")
            logger.debug(f"validator: {self.validator}")
            logger.debug(f"patcher: {self.patcher}")
            logger.debug(f"function end: {function_name}")
    # function end: init


# In[ ]:


class Metadata_Workflow(Metadata):

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")

        super().__init__(metadata_yml, logger, debug)

        metadata = self.metadata
        
        # get the configuraitons from the yaml file
        self.active = metadata["active"]
        self.dataflows = metadata["dataflows"]

        if debug:
            logger.debug("metadata detail:")
            logger.debug(f"active: {self.active}")
            logger.debug(f"dataflows: {self.dataflows}")
            logger.debug(f"function end: {function_name}")

    # function end: init


# In[ ]:


class Metadata_Task(Metadata):

    def __init__(self, metadata_yml, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug("##debug begin: class Metadata_Task.init")

        super().__init__(metadata_yml, logger, debug)

        metadata = self.metadata
        
        # get the configuraitons from the yaml file
        # reader
        #self.environment = metadata
        self.debug = metadata["debug"]
        self.active = metadata["active"]
        self.workflows = metadata["workflows"]

        if debug:
            logger.debug("metadata detail:")
            #logger.debug(f"environment: {self.environment}")
            logger.debug(f"debug: {self.debug}")
            logger.debug(f"active: {self.active}")
            logger.debug(f"workflows: {self.workflows}")
            logger.debug("##debug end: class Metadata_task.init\n")
    # function end: init


# In[ ]:


class Metadata_Log(Metadata):

    def __init__(self, metadata_yml, log_folder, log_timestamp, log_file_name):
        function_name = "__init__"

        super().__init__(metadata_yml, None, False)
        self.log_folder = log_folder
        self.log_timestamp = log_timestamp
        self.log_file_name = log_file_name
        self.log_year = log_timestamp[0:4]
        self.log_month = log_timestamp[5:7]
        self.log_day = log_timestamp[8:10]

    def get_config(self):
        config = self.metadata

        handlers = config["handlers"]
        for x in handlers:
            handler = handlers[x]
            key = "filename"
            if key in handler:
                value = handler[key].replace("<log_folder>", self.log_folder) \
                        .replace("<log_year>", self.log_year) \
                        .replace("<log_month>", self.log_month) \
                        .replace("<log_day>", self.log_day) \
                        .replace("<log_timestamp>", self.log_timestamp) \
                        .replace("<file_name>", self.log_file_name) 
            
                handler[key] = value
                

                # create the folder if not exists
                pathlib.Path(value).parent.mkdir(parents = True, exist_ok = True)
        
        return config

    # function end: init


# In[ ]:


class Metadata_Model(Metadata):
    def __init__(self, metadata_yml, debug = False):

        super().__init__(metadata_yml, None, debug)

        metadata = self.metadata
        self.models = metadata["models"]

