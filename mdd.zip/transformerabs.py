#!/usr/bin/env python
# coding: utf-8

# ## transformerabs
# 
# New notebook

# In[35]:


from pyspark.sql import *
from pyspark.sql.types import *
import pyspark.sql.functions as F
from typing import Tuple, List

from delta.tables import *
import datetime as mdt
import logging
import notebookutils
from abc import abstractmethod, ABC

from env.mdd.metadata import *
from env.mdd.datamanifest import *
from env.mdd.datareader import *
from env.mdd.datawriter import *
from env.mdd.datavalidator import *
from env.mdd.mddutils import *
from env.mdd.environment import Environment


# In[36]:


@DecoratorUtil.add_logger()
class TransformerAbs():
    logger: logging.Logger


    def __init__(
        self, 
        metadata_dataflow_yml: str, 
        data_sync_options: dict, 
        spark: SparkSession, 
        debug: BooleanType = False,
        job_name = "job_123", job_start_timestamp = None, task_name = "task_123", task_start_timestamp = None
    ):
        self.metadata = Metadata_Transform_Dataflow(metadata_dataflow_yml, self.logger, debug)
        self.data_sync_options = data_sync_options
        self.job_name = job_name
        self.job_start_timestamp = job_start_timestamp
        self.task_name = task_name
        self.task_start_timestamp = task_start_timestamp
        self.spark = spark
        self.debug = debug

        self.task_run_id = f"{self.task_name}_{self.task_start_timestamp}"
        self.job_run_id = f"{self.job_name}_{self.job_start_timestamp}"
        self.source_primarykey = FunctionUtil.string_to_list(self.metadata.source_primarykey) 
        self.destination_primarykey = FunctionUtil.string_to_list(self.metadata.destination_primarykey) 

    @DecoratorUtil.log_function()
    def _transform(self, df: DataFrame, spark: SparkSession, debug: BooleanType) -> Tuple[DataFrame, List]:
        secondary_tables = []
        return df, secondary_tables


    @DecoratorUtil.log_function()
    def _pre_write(self):
        if not (self.metadata.destination_write_prescript is None or self.metadata.destination_write_prescript == ""):
            self.logger.info(f"write prescript start")
            # get the sql script
            script_path = f"{Environment.root_path_metadata}{self.metadata.destination_write_prescript}"  
            with open(script_path, 'r') as file:
                sqlscript = file.read()
            DeltaTableUtil.run_sql_script(sqlscript, self.spark, self.debug)
            self.logger.info(f"write prescript end")

    @DecoratorUtil.log_function()
    def _post_write(self):
        if not (self.metadata.destination_write_postscript is None or self.metadata.destination_write_postscript == ""):
            self.logger.info(f"write postscript start")
            # get the sql script
            script_path = f"{Environment.root_path_metadata}{self.metadata.destination_write_postscript}"
            with open(script_path, 'r') as file:
                sqlscript = file.read()
            DeltaTableUtil.run_sql_script(sqlscript, self.spark, self.debug)
            self.logger.info(f"write postscript end")

    @DecoratorUtil.log_function()
    def _clean_data(self, df: DataFrame):
        source_deduplication_expr = "_commit_timestamp desc"
        df = DeltaTableUtil.deduplicate(df, self.source_primarykey, source_deduplication_expr)

        condition = expr("""
            CASE
                WHEN _deleted_by_source = true
                    OR _deleted_by_validation = true
                    OR (_corrupt_data IS NOT NULL AND _corrupt_data != '')
                    OR _change_type = 'delete'
                THEN true
                ELSE false
            END
        """)

        df = (
            df.withColumn("_deleted_by_source", condition)
            .withColumn("_source_name", lit(self.metadata.source_table_name))
            .withColumn("_source_timestamp", col("_record_timestamp"))
            .withColumn("_source_cdfversion", col("_commit_version"))
        )

        drop_columns = [
            "_corrupt_data",
            "_deleted_by_validation",
            "_data_validation_expectations",
            "_record_id",
            "_record_timestamp",
            "_change_type",
            "_commit_version",
            "_commit_timestamp"
        ]
        df = DeltaTableUtil.safe_drop_columns(df, drop_columns)

        return df

    @DecoratorUtil.log_function()
    def run(self):
        self.logger.info(f"data sync start: {self.metadata.source_table_name} -> {self.metadata.destination_table_name}")
        sync_start_timestamp = mdt.datetime.now()

        if self.data_sync_options["incremental_by"] == "timestamp":
            self.logger.info(f"not-existed records process start")
            self.logger.info(f"not-existed records process end")

        # get the new data
        self.logger.info(f"read start")
        read_start_timestamp = mdt.datetime.now()

        # get new data
        datamanifest = TableDataManifest(self.spark, self.debug)
        df_batches = datamanifest.get(self.metadata.source_table_name, self.metadata.destination_table_name, self.data_sync_options)
        df_source = datamanifest.source_data_df

        # check data sync mode fallback
        data_sync_mode = self.data_sync_options["data_sync_mode"]
        data_sync_mode_final = datamanifest.data_sync_mode_final
        if data_sync_mode != data_sync_mode_final:
            data_sync_mode_final = f"{data_sync_mode} -> {data_sync_mode_final}"
            msg = f"data sync mode fallback: {data_sync_mode_final}"
            self.logger.warning(msg)  

        rows_read = df_source.count()
        read_end_timestamp = mdt.datetime.now()
        self.logger.info(f"rows read: {rows_read}")
        self.logger.info(f"read end")

        batches_total = len(df_batches)
        if batches_total == 0:
            self.logger.warning("skipped with no data")
            return

        # run the destination_write_prescript
        self._pre_write()

        if len(df_batches) > 1:
            self.logger.info(f"rows per batch: {self.data_sync_options['rows_per_batch']}")
            self.logger.info(f"total batches: {len(df_batches)}")

        batch_i = 0
        for batch in df_batches[:]:
            batch_i += 1

            rows_in_batch = rows_read
            batch_detail = f"{batch_i}/{batches_total}: {batch[0].strftime('%Y-%m-%d %H:%M:%S.%f')} - {batch[1].strftime('%Y-%m-%d %H:%M:%S.%f')}"

            if len(df_batches) == 1:
                df_batch = df_source
            else:
                df_batch = df_source.filter((df_source._commit_timestamp >= batch[0]) & (df_source._commit_timestamp <= batch[1]))
                rows_in_batch = df_batch.count()
                self.logger.info(f"process batch {batch_detail}")
                self.logger.info(f"rows read: {rows_in_batch}")

                # skip and warning if current batch has no data
                if df_batch.isEmpty():
                    self.logger.warning(f"batch {batch_i} has no data: {batch[0]} - {batch[1]}")
                    continue

            # transform
            self.logger.info(f"transform start")
            transform_start_timestamp = mdt.datetime.now()

            df_cleaned = self._clean_data(df_batch)
            df_transformed, secondary_tables = self._transform(df_cleaned, self.spark, self.debug)

            transform_end_timestamp = mdt.datetime.now()
            self.logger.info(f"transform end")

            if df_transformed is None:
                msg = f"transform returns None"
                self.logger.error(f"transform returns None")
                raise Exception(msg)
            if df_transformed.isEmpty():
                self.logger.warning(f"transform returns no data")
                continue
            
            # add the source table as _source_name
            df_transformed = df_transformed.withColumn("_source_name", lit(self.metadata.source_table_name))

            # write
            write_start_timestamp = mdt.datetime.now()
            destination_table_full_path = DeltaTableUtil.get_table_full_path(self.metadata.destination_table_name)
            write_config = {
                    "source_table_name": self.metadata.source_table_name,
                    "destination_table_full_path": destination_table_full_path,
                    "destination_table_name": self.metadata.destination_table_name,
                    "destination_write_mode": self.metadata.destination_write_mode,
                    "destination_write_options": self.metadata.destination_write_options,
                    "destination_projected_sql": self.metadata.destination_projected_sql,
                    "metadata_validator_yml": self.metadata.validator,
                    "destination_primarykey": self.destination_primarykey,
                    "destination_deduplication_expr": self.metadata.destination_deduplication_expr,
                    "destination_watermark_column": self.metadata.destination_watermark_column,
                    "destination_update_changes_only": self.metadata.destination_update_changes_only,
                    "task_run_id": self.task_run_id,
                    "task_start_timestamp": self.task_start_timestamp,
                    "job_run_id": self.job_run_id
            }
            datawriter = DataWriter(df_transformed, write_config, self.spark, self.debug)
            datawriter.write()
            rows_inserted = datawriter.rows_inserted
            rows_updated = datawriter.rows_updated
            rows_deleted = datawriter.rows_deleted
            write_end_timestamp = mdt.datetime.now() 

            # log sync information
            table_run_id = f"{self.metadata.destination_table_name}_{sync_start_timestamp.strftime('%Y-%m-%d %H:%M:%S.%f')}"
            
            source_table_timestamp = df_batch.select(max("_record_timestamp")).collect()[0][0]
            source_table_cdfversion = df_batch.select(max("_commit_version")).collect()[0][0]
            table_run_timestamp = mdt.datetime.now() 
            secondary_tables_str = ",".join(secondary_tables)
            JobUtil.etl_job_tables_update(    
                table_run_id              
                ,self.metadata.destination_table_name               
                ,data_sync_mode_final 
                ,self.metadata.destination_write_mode          
                ,self.metadata.source_table_name        
                ,source_table_timestamp   
                ,source_table_cdfversion   
                ,rows_read                
                ,batches_total                  
                ,batch_detail                    
                ,rows_in_batch            
                ,rows_inserted
                ,rows_updated             
                ,rows_deleted             
                ,read_start_timestamp     
                ,read_end_timestamp       
                ,transform_start_timestamp
                ,transform_end_timestamp  
                ,write_start_timestamp    
                ,write_end_timestamp  
                ,secondary_tables_str    
                ,self.task_run_id              
                ,self.job_run_id               
                ,table_run_timestamp            
            )
        # end for

        # run the destination_write_prescript
        self._post_write()

        # run table validator
        
        if self.metadata.validator is not None and self.metadata.validator != "":
            self.logger.info(f"table validation start")
            DataValidator.validate_query(
                table_name = self.metadata.destination_table_name,
                yaml_path = self.metadata.validator,
                spark = self.spark,
                logger = self.logger,
                task_run_id = self.task_run_id,
                task_start_timestamp = self.task_start_timestamp,
                job_run_id = self.task_run_id
            )
            self.logger.info(f"table validation end")

        self.logger.info(f"data sync end: {self.metadata.source_table_name} -> {self.metadata.destination_table_name}")

