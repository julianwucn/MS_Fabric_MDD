#!/usr/bin/env python
# coding: utf-8

# ## datalander_mssql
# 
# New notebook

# In[ ]:


import pyodbc
import logging
from pyspark.sql.functions import *
from notebookutils import mssparkutils

from env.mdd.metadata import *
from env.mdd.datalanderfactory import *


# In[ ]:


@DataLanderFactory.register('mssql')
class MSSQLDataLander(DataLanderBase):
    def __init__(self, metadata_environment_yml, metadata_lander_yml, spark, logger, debug = False):
        function_name = "__init__"
        
        if debug:
            logger.debug(f"function begin: {function_name}")

        super().__init__(metadata_environment_yml, metadata_lander_yml, spark, logger, debug)

        if debug:
            logger.debug(f"function end: {function_name}")

    # function end: init

    def run(self):
        function_name = "run"

        metadata_environment = Metadata_Environment(self.metadata_environment_yml, self.logger, True)
        source_data_root_path = metadata_environment.source_data_root_path
        destination_lakehouse = metadata_environment.destination_lakehouse
        destination_lakehouse_guid = metadata_environment.destination_lakehouse_guid
        destination_bronze_schema = metadata_environment.destination_bronze_schema
        destination_silver_schema = metadata_environment.destination_silver_schema
        destination_gold_schema = metadata_environment.destination_gold_schema


        metadata_lander = Metadata_Lander(self.metadata_lander_yml, destination_bronze_schema, destination_bronze_schema, destination_gold_schema, self.logger, True)
        source_server_options = metadata_lander.source_server_options
        data_landers = metadata_lander.data_landers
        #print(source_server_options)
        #print(data_landers)

        # get server connecitons
        server_type = source_server_options["server_type"]
        server_name = source_server_options["server_name"]
        db_name = source_server_options["database_name"]
        user_name = source_server_options["server_credential"]["user_name"]
        user_pwd = source_server_options["server_credential"]["password"]
        #print(user_pwd)
        # get the password from key vault
        if user_pwd is None:
            password_keyvault = source_server_options["server_credential"]["password_keyvault"]
            password_secret = source_server_options["server_credential"]["password_secret"]
            user_pwd = mssparkutils.credentials.getSecret(password_keyvault, password_secret)

        connectionString = f'DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={server_name};DATABASE={db_name};UID={user_name};PWD={user_pwd}'
        #print(connectionString)
        conn = pyodbc.connect(connectionString)
        try:
            for lander in data_landers:
                #print(lander)

                lander_active = lander["active"]
                lander_debug = lander["debug"]
                if not lander_active:
                    continue

                # data_read_options
                data_read_options = lander["data_read_options"]
                table_name = data_read_options['dbtable']
                data_schema = data_read_options["data_schema"]

                # data_write_options
                data_write_options = lander["data_write_options"]
                file_relative_path = data_write_options["relative_path"]
                file_format = data_write_options["file_format"]
                file_full_path = f"{source_data_root_path}{file_relative_path}"

                # data_sync_options
                data_sync_options = lander["data_sync_options"]
                sync_mode = data_sync_options["sync_mode"]
                full_projected_sql = data_sync_options["full_projected_sql"]
                if full_projected_sql is None:
                    full_projected_sql = ""
                is_incremental = 1
                if sync_mode == "full":
                    is_incremental = 0
                
                # get last landing version
                last_sync_version = None
                sql_query = f"""
                        select *, row_number() over (order by landing_timestamp desc) as rno 
                        from mdd.landing_file_history 
                        where landing_path = '{file_full_path}'
                            and server_name = '{server_name}'
                            and database_name = '{db_name}'
                            and table_name = '{table_name}'
                    """
                #print(sql_query)
                df = self.spark.sql(sql_query).where("rno = 1")
                #display(df)
                if not df.isEmpty():
                    last_sync_version = df.first()["landing_version"]
                if self.debug:
                    self.logger.debug(f"last_sync_version: {last_sync_version}")

                self.logger.info(f"read start: {table_name}")
                sql_query = "{CALL dbo.uspFabricMDDExtractData(?, ?, ?, ?)}" 
                cursor = conn.cursor()
                cursor.execute(sql_query, (table_name, is_incremental, last_sync_version, full_projected_sql))
                #print(f"cursor.description: {cursor.description[:]}")
                #for col in cursor.description[:]:
                #    print(f"{col[0]} {col[1]}({col[4]}, {col[5]})")
                data_columns = [column[0] for column in cursor.description]
                data_rows = [dict(zip(data_columns, row)) for row in cursor.fetchall()] 
                    
                if data_schema is None:
                    data_schema = ""
                    for col in cursor.description[:]:
                        match col[1]:
                            case "<class 'int'>": data_schema = f"{data_schema}{col[0]} int, "
                            case "<class 'bigint'>": data_schema = f"{data_schema}{col[0]} bigint, "
                            case "<class 'bool'>": data_schema = f"{data_schema}{col[0]} bool, "
                            case "<class 'decimal.Decimal'>": data_schema = f"{data_schema}{col[0]} decimal({col[4]}, {col[5]}), "
                            case "<class 'float'>": data_schema = f"{data_schema}{col[0]} float, "
                            case "<class 'datetime.date'>": data_schema = f"{data_schema}{col[0]} date, "
                            case "<class 'datetime.time'>": data_schema = f"{data_schema}{col[0]} timestamp, "
                            case "<class 'datetime.datetime'>": data_schema = f"{data_schema}{col[0]} timestamp, "
                            case _: data_schema = f"{data_schema}{col[0]} string, "
                    data_schema = data_schema[:-2]
                else:
                    data_schema = f"{data_schema},land_sys_change_version:integer,land_sys_change_operation:string,land_partition_year:string,land_partition_month:string,land_partition_day:string"

                if self.debug:
                    self.logger.debug(f"data_schema: {data_schema}")
                cursor.close()

                data_df = self.spark.createDataFrame(data_rows, data_schema)
                self.logger.info(f"read total rows: {data_df.count()}")
                self.logger.info(f"read end: {table_name}")

                if data_df.isEmpty():
                    continue

                # save the data
                self.logger.info(f"write start: {file_full_path}")
                if (not data_df.isEmpty()):
                    partition_by = []
                    data_df_firstrow = data_df.first()

                    if data_df_firstrow["land_partition_year"]:
                        partition_by.append("land_partition_year")
                    if data_df_firstrow["land_partition_month"]:
                        partition_by.append("land_partition_month")
                    if data_df_firstrow["land_partition_day"]:
                        partition_by.append("land_partition_day")
                    
                    if data_df_firstrow["land_sys_change_operation"] == "F":
                        write_mode = "overwrite"
                        landing_mode = "Full"
                    else:
                        write_mode = "append"
                        landing_mode = "Incremental"
                    
                    if self.debug:
                        self.logger.debug(f"partition_by: {partition_by}")
                        self.logger.debug(f"write_mode: {write_mode}")
                        self.logger.debug(f"landing_mode: {landing_mode}")

                    if len(partition_by) == 0:
                        data_df.write.format(file_format).mode(write_mode).save(file_full_path)
                    else:
                        data_df.write.format(file_format).mode(write_mode).partitionBy(*partition_by).save(file_full_path)

                    self.logger.info(f"write end: {file_full_path}")

                    # record the max land_sys_change_version
                    landing_data_history = data_df.select(max(data_df.land_sys_change_version).cast('int').alias("landing_version")) \
                                                    .withColumn("landing_path", lit(file_full_path)) \
                                                    .withColumn("server_name", lit(server_name)) \
                                                    .withColumn("database_name", lit(db_name)) \
                                                    .withColumn("table_name", lit(table_name)) \
                                                    .withColumn("total_rows", lit(data_df.count())) \
                                                    .withColumn("landing_mode", lit(landing_mode)) \
                                                    .withColumn("landing_timestamp", lit(current_timestamp())) \
                                                    .select("landing_path", "server_name", "database_name", "table_name", "total_rows", "landing_mode", "landing_version", "landing_timestamp")
                                                    
                    #display(landing_data_history)
                    #landing_data_history.printSchema()

                    landing_data_history.write.mode("append").saveAsTable("mdd.landing_file_history")
        finally:
            conn.close()

    # function end: run


