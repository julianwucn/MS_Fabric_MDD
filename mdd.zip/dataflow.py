#!/usr/bin/env python
# coding: utf-8

# ## dataflow
# 
# New notebook

# In[ ]:


# The command is not a standard IPython magic command. It is designed for use within Fabric notebooks only.
# %run install_pub_packages


# In[ ]:


# Use the 2 magic commands below to reload the modules if your module has updates during the current session. You only need to run the commands once.
# %load_ext autoreload
# %autoreload 2
# import
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from delta import *
from delta.tables import *
import datetime as mdt
import os
import re
import sys
import json
import logging
import notebookutils

from inspect import isclass
from pkgutil import iter_modules
from pathlib import Path

from env.mdd.metadata import *
from env.mdd.datamanifest import *
from env.mdd.datareader import *
from env.mdd.datawriter import *
from env.mdd.transformerabs import *
from env.mdd.datavalidator import *
from env.mdd.mddutils import *
from env.mdd.environment import Environment

from env.mdd.onboarder import *
from env.mdd.transformerabs import *


# In[ ]:


@DecoratorUtil.add_logger()
class Dataflow:
    def __init__(self, metadata_dataflow_yml, data_sync_options, spark, debug = False, metadata_log_yml = None, job_name = "job_123", job_start_timestamp = None, task_name = "task_123", task_start_timestamp = None):
        self.metadata_dataflow_yml = metadata_dataflow_yml
        self.data_sync_options = data_sync_options
        self.spark = spark
        self.debug = debug
        self.metadata_log_yml = metadata_log_yml
        self.job_name = job_name
        self.job_start_timestamp = job_start_timestamp
        self.task_name = task_name
        self.task_start_timestamp = task_start_timestamp

    @DecoratorUtil.log_function()
    def run(self):
        # dataflow metadata  
        metadata_dataflow = Metadata_Dataflow(self.metadata_dataflow_yml, self.logger, self.debug) 
        dataflow_type = metadata_dataflow.dataflow_type.lower()
        
        if dataflow_type in ("onboarding", "onboard"):
            onboarder = Onboarder(self.metadata_dataflow_yml, self.data_sync_options, self.spark, self.debug, self.job_name, self.job_start_timestamp, self.task_name, self.task_start_timestamp)
            onboarder.run()
        elif dataflow_type in ("transform", "transforming", "tranfromation"):
            metadata_dataflow = Metadata_Transform_Dataflow(self.metadata_dataflow_yml, self.logger, self.debug) 
            if isinstance(self.job_start_timestamp, str):
                job_start_timestamp_str = self.job_start_timestamp
            else:
                job_start_timestamp_str = self.job_start_timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")
            if isinstance(self.task_start_timestamp, str):
                task_start_timestamp_str = self.task_start_timestamp
            else:
                task_start_timestamp_str = self.task_start_timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")

            params = {
                "log_yml": self.metadata_log_yml,
                "job_name": self.job_name,
                "job_start_timestamp": job_start_timestamp_str,
                "task_name": self.task_name,
                "task_start_timestamp": task_start_timestamp_str,
                "dataflow_yml": self.metadata_dataflow_yml,
                "data_sync_options": self.data_sync_options,
                "debug": self.debug
            }
            params_json = json.dumps(params)
            timeoutSeconds = 60*60*12
            notebookutils.notebook.run(metadata_dataflow.transformer, timeoutSeconds, {"params": params_json})
        else:
            msg = f"dataflow_type: '{dataflow_type}' in metadata '{self.metadata_dataflow_yml}' is not supported"
            raise Exception(msg)

