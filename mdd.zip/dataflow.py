#!/usr/bin/env python
# coding: utf-8

# ## dataflow
# 
# New notebook

# In[ ]:


# Use the 2 magic commands below to reload the modules if your module has updates during the current session. You only need to run the commands once.
# %load_ext autoreload
# %autoreload 2

# import
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from delta import *
from delta.tables import *
import datetime as mdt
import re
import json
import uuid
import logging

from inspect import isclass
from pkgutil import iter_modules
from pathlib import Path
from importlib import import_module

from env.mdd.metadata import *
from env.mdd.datasyncmanifest import *
from env.mdd.datareaderfactory import *
from env.mdd.datawriter import *
from env.mdd.transformer import *
from env.mdd.patcher import *
from env.mdd.validator import *
from env.mdd.utilhelper import *
import env.mdd.common as common
from env.mdd.utilhelper import *

# import all data readers
package_dir = common.datareaders_package_path
module_path_list = package_dir.split("/")
module_path_list.remove(".")
module_path = ".".join(module_path_list)
for (_, module_name, _) in iter_modules([package_dir]):
    module_name = f"{module_path}.{module_name}"
    module = import_module(module_name) 


# In[ ]:


class DataflowHelper:
    def create_dataflow(self, metadata_dataflow_yml, metadata_environment_yml, data_sync_options, spark, debug = False):
        logger_name = f"mdd.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        # dataflow metadata       
        metadata_dataflow = Metadata_Dataflow(metadata_dataflow_yml, debug) 
        dataflow_type = metadata_dataflow.dataflow_type
        
        if dataflow_type == "onboarding":
            return Onboarding_Dataflow(metadata_dataflow_yml, metadata_environment_yml, data_sync_options, spark, logger, debug)
        elif dataflow_type == "transform":
            return Transform_Dataflow(metadata_dataflow_yml, metadata_environment_yml, data_sync_options, spark, logger, debug)
        elif dataflow_type == "load":
            return Load_Dataflow(metadata_dataflow_yml, metadata_environment_yml, data_sync_options, spark, logger, debug)
        else:
            msg = f"dataflow_type: '{dataflow_type}' in metadata '{metadata_dataflow_yml}' is not supported"
            logger.error(msg)


# In[ ]:


class Onboarding_Dataflow:

    def __init__(self, metadata_dataflow_yml, metadata_environment_yml, data_sync_options, spark, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")
            logger.debug(f"metadata_environment_yml: {metadata_environment_yml}")
            logger.debug(f"metadata_dataflow_yml: {metadata_dataflow_yml}")
            logger.debug(f"data_sync_options: {data_sync_options}")

        self.spark = spark
        self.debug = debug
        self.logger = logger

        # environment metadata
        self.metadata_environment = Metadata_Environment(metadata_environment_yml, debug)

        # dataflow metadata       
        self.metadata_dataflow = Metadata_Onboarding_Dataflow(metadata_dataflow_yml, debug) 
          
        # data sync options
        self.data_sync_options = data_sync_options    

        if debug:
            logger.debug(f"function end: {function_name}")
    # function end: init 
    

    # execute the dataflow 
    def run(self):
        function_name = "run"
        if self.debug:
            self.logger.debug(f"function begin: {function_name}")

        m_df = self.metadata_dataflow
        m_en = self.metadata_environment


        # reader metadata
        source_data_format = m_df.source_data_format
        source_data_path = f"{m_en.source_data_root_path}{m_df.source_data_relative_path}"
        source_file_name_regex = m_df.source_file_name_regex
        source_data_read_options = m_df.Source_data_read_options
        source_data_schema = m_df.source_data_schema

        # writer metadata
        destination_lakehouse = m_en.destination_lakehouse
        destination_lakehouse_guid = m_en.destination_lakehouse_guid
        destination_bronze_schema = m_en.destination_bronze_schema
        destination_projected_sql = m_df.destination_projected_sql
        destination_write_mode = m_df.destination_write_mode
        destination_write_options = m_df.destination_write_options
        
        # validator metadata
        metadata_validator_yml = m_df.validators


        # prepare local variables
        destination_table_name = f"{m_en.destination_bronze_schema}.{m_df.destination_table_name}"
        destination_table_full_name = f"{m_en.destination_lakehouse}.{m_en.destination_bronze_schema}.{m_df.destination_table_name}"
        destination_table_full_path = f"/{m_en.destination_lakehouse_guid}/Tables/{m_en.destination_bronze_schema}/{m_df.destination_table_name}"
        if self.debug:
            self.logger.debug(f"destination_table_full_name: {destination_table_full_name}")
            self.logger.debug(f"destination_table_full_path: {destination_table_full_path}")

        # check destination table 
        if not self.spark.catalog.tableExists(destination_table_full_name):
            raise Exception(f"table {destination_table_full_name} does not exist, please create the table.")

        # use the schema of the destination table if source data schema is not defined
        if source_data_schema is None or source_data_schema == "":
            source_data_schema = self.spark.read.table(destination_table_full_name).schema
            if self.debug:
                self.logger.debug(f"warning: source_data_schema not defined, use destination table schema instead")            
        else:
            source_data_schema = source_data_schema + ", _corrupt_data string"


        # get the loaded files list
        #destination_files_df = self.spark.sql(f"select distinct _source_name as file_name, _source_timestamp as file_modification_timestamp from {destination_table_full_name}")
        destination_files_df = self.spark.sql(f"select distinct file_name, file_modification_timestamp from mdd.onboarding_file_history where table_name = '{destination_table_name}'")
        destination_files = list((row["file_name"], row["file_modification_timestamp"]) for row in destination_files_df.collect())
        if self.debug:
            self.logger.debug(f"destination_files_df: {destination_files_df.count()}")
            display(destination_files_df.sort(destination_files_df.file_name.desc()))
            self.logger.debug(f"destination_files: {destination_files}")

        # get the new files
        data_sync_manifest = FileDataSyncManifest(self.spark, self.debug)
        data_sync_manifest_group_list = data_sync_manifest.get_data_sync_manifest(source_data_path, source_file_name_regex, destination_files, self.data_sync_options)
        data_sync_manifest_files = data_sync_manifest.data_sync_manifest_files
        data_sync_manifest_df = data_sync_manifest.data_sync_manifest_df

        # loop the file groups, read the data and write to destination
        self.logger.info(f"{m_df.dataflow_type} start: {destination_table_name}") 
        
        self.logger.info(f"files path: {source_data_path}")
        self.logger.info(f"files in total: {data_sync_manifest_files}")
        if data_sync_manifest_files > 0:
            self.logger.info(f"files per batch: {self.data_sync_options['files_per_batch']}")
            self.logger.info(f"batches in total: {len(data_sync_manifest_group_list)}")

        schema_bronze = m_en.destination_bronze_schema
        schema_silver = m_en.destination_silver_schema
        schema_gold = m_en.destination_gold_schema
        i = 0
        for file_path_list in data_sync_manifest_group_list[:]:
            i += 1
            self.logger.info(f"batch #{i} start")
            self.logger.info(f"files in batch: {len(file_path_list)}")

            source_options = {
                    "source_format": source_data_format,
                    "source_read_options": source_data_read_options,
                    "source_schema":source_data_schema
                }
            
            datareader = DataReaderFactory.create_datareader(source_data_format, source_options, self.spark, self.debug)
            if datareader is None:
                self.logger.error(f"the data reader for '{source_data_format}' is not registered")

            self.logger.info(f"read start")
            batch_data_df = datareader.read(file_path_list)
            if batch_data_df is not None:
                self.logger.info(f"read rows in total: {batch_data_df.count()}")

            self.logger.info(f"write start")
            imported_files_df = data_sync_manifest_df.where(data_sync_manifest_df.file_path.isin(file_path_list)) 
                                                                                
            if batch_data_df is not None:
                # write the validated data into destination table
                datawriter = BronzeDataWriter(batch_data_df, destination_table_full_path, destination_table_name, destination_write_mode, \
                    destination_write_options, destination_projected_sql, metadata_validator_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
                datawriter.write()

                total_rows_df = batch_data_df.withColumns({"file_name": "_metadata.file_name", "file_modification_timestamp": "_metadata.file_modification_time"}) \
                                        .groupBy("file_name", "file_modification_timestamp")\
                                        .agg(count("*").alias("total_rows"))

                imported_files_df = imported_files_df.join(total_rows_df, ["file_name", "file_modification_timestamp"], "left") \
                                        .select(imported_files_df["*"], total_rows_df["total_rows"]).fillna({"total_rows": 0})
            else:
                imported_files_df = imported_files_df.withColumn("total_rows", lit(long(0)))

            # save the state of the imported files with timestamp
            #imported_files_df.printSchema()
            imported_files_df.withColumn("table_name", lit(destination_table_name)).withColumn("onboarding_timestamp",lit(current_timestamp())) \
                            .select("table_name", "file_name", "file_modification_timestamp", "file_path", "total_rows", "file_date", "onboarding_timestamp") \
                            .write.mode("append").option("mergeSchema", "true").saveAsTable("mdd.onboarding_file_history")
            

        # end for

        # run table validators
        self.logger.info(f"table validation start")
        if metadata_validator_yml is not None and metadata_validator_yml != "":
            validator_table = TableValidator(metadata_validator_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            validator_table.validate(destination_table_name, destination_table_full_path)
        self.logger.info(f"table validation end")

        self.logger.info(f"{m_df.dataflow_type} end: {destination_table_name}") 
        if self.debug:
            self.logger.debug(f"function end: {function_name}")
    # function end: run


# In[ ]:


class Transform_Dataflow:

    def __init__(self, metadata_dataflow_yml, metadata_environment_yml, data_sync_options, spark, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")
            logger.debug(f"metadata_environment_yml: {metadata_environment_yml}")
            logger.debug(f"metadata_dataflow_yml: {metadata_dataflow_yml}")
            logger.debug(f"data_sync_options: {data_sync_options}")

        self.spark = spark
        self.debug = debug
        self.logger = logger

        # environment metadata
        self.metadata_environment = Metadata_Environment(metadata_environment_yml, debug)

        # dataflow metadata       
        self.metadata_dataflow = Metadata_Transform_Dataflow(metadata_dataflow_yml, debug) 
          
        # data sync options
        self.data_sync_options = data_sync_options

        if debug:
            logger.debug(f"function end: {function_name}")
    # function end: init 
    

    # execute the dataflow 
    def run(self):
        function_name = "run"
        if self.debug:
            self.logger.debug(f"function begin: {function_name}")
        
        m_en = self.metadata_environment
        m_df = self.metadata_dataflow

        # map schema holder to schema
        map_table_schema = lambda x: x.replace("<bronze>", m_en.destination_bronze_schema) \
                                    .replace("<silver>", m_en.destination_silver_schema) \
                                    .replace("<gold>", m_en.destination_gold_schema)

        # get source table name
        source_lakehouse = m_en.destination_lakehouse
        source_table_schema = map_table_schema(m_df.source_table_schema)
        source_table_name = f"{source_table_schema}.{m_df.source_table_name}"
        source_table_full_name = f"{source_lakehouse}.{source_table_schema}.{m_df.source_table_name}"
        if self.debug:
            self.logger.debug(f"source_table_name: {source_table_name}")
            self.logger.debug(f"source_table_full_name: {source_table_full_name}")
        
        # get destination table name
        destination_lakehouse = m_en.destination_lakehouse
        destination_table_schema = map_table_schema(m_df.destination_table_schema)
        destination_table_name = f"{destination_table_schema}.{m_df.destination_table_name}"
        destination_table_full_name = f"{destination_lakehouse}.{destination_table_schema}.{m_df.destination_table_name}"
        destination_table_full_path = f"/{m_en.destination_lakehouse_guid}/Tables/{destination_table_schema}/{m_df.destination_table_name}"
        destination_write_mode = m_df.destination_write_mode
        metadata_validator_yml = m_df.validators
        destination_projected_sql = m_df.destination_projected_sql
        destination_write_options = m_df.destination_write_options
        if self.debug:
            self.logger.debug(f"destination_table_name: {destination_table_name}")
            self.logger.debug(f"destination_table_full_name: {destination_table_full_name}")
            self.logger.debug(f"destination_table_full_path: {destination_table_full_path}")
            self.logger.debug(f"destination_write_mode: {destination_write_mode}")
            self.logger.debug(f"metadata_validator_yml: {metadata_validator_yml}")
            self.logger.debug(f"destination_projected_sql: {destination_projected_sql}")
            self.logger.debug(f"destination_write_options: {destination_write_options}")

        # register the main source table
        property_name = "mdd.source.primary"
        tableutil = TableUtil(destination_table_name, self.spark, self.debug)
        tableutil.set_table_property_list(property_name, source_table_name)

        # get final data sync options generate by the data sync manifest
        data_sync_manifest = TableDataSyncManifest(self.spark, self.debug)
        data_sync_manifest_group_list = data_sync_manifest.get_data_sync_manifest(source_table_name, destination_table_name, self.data_sync_options)
        source_data_df = data_sync_manifest.source_data_df

        # loop the file groups, read, transform and write the data to destination
        transformers = m_df.transformers
        if self.debug:
            self.logger.debug(f"transformers: {transformers}")

        self.logger.info(f"{m_df.dataflow_type} start: {source_table_name} -> {destination_table_name}")
        data_sync_mode = self.data_sync_options["data_sync_mode"]
        data_sync_mode_final = data_sync_manifest.data_sync_mode_final
        if data_sync_mode != data_sync_mode_final:
            msg = f"data_sync_mode fallback: {data_sync_mode} -> {data_sync_mode_final}"
            self.logger.warning(msg)  

        total_rows = source_data_df.count()
        self.logger.info(f"total rows: {total_rows}")
        if total_rows > 0:
            self.logger.info(f"rows per batch: {self.data_sync_options['rows_per_batch']}")
            self.logger.info(f"total batches: {len(data_sync_manifest_group_list)}")
        
        schema_bronze = m_en.destination_bronze_schema
        schema_silver = m_en.destination_silver_schema
        schema_gold = m_en.destination_gold_schema
        i = 0
        for batch_timestamps in data_sync_manifest_group_list[:]:
            i += 1
            batch_data_df = source_data_df.filter((source_data_df._commit_timestamp >= batch_timestamps[0]) & (source_data_df._commit_timestamp <= batch_timestamps[1]))
            self.logger.info(f"process batch {i}: {batch_timestamps[0].strftime('%Y-%m-%d %H:%M:%S.%f')} - {batch_timestamps[1].strftime('%Y-%m-%d %H:%M:%S.%f')}")
            self.logger.info(f"total rows: {batch_data_df.count()}")
                
            # if no data, skip
            if batch_data_df.isEmpty():
                self.logger.warning(f"batch_data_df: no data")
                continue

            # transform
            transformerhelper = TransformerHelper(destination_table_name, batch_data_df, transformers, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            batch_data_transformed_df = transformerhelper.run().withColumn("_source_name", lit(source_table_name))

            # write
            self.logger.info(f"write start")
            datawriter = SilverDataWriter(batch_data_transformed_df, destination_table_full_path, destination_table_name, destination_write_mode, \
                destination_write_options, destination_projected_sql, metadata_validator_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            datawriter.write()       
            self.logger.info(f"write end")
        # end for

        # soft-delete the deleted rows if the data is incremental sync-ed by timestmap
        data_sync_mode = self.data_sync_options["data_sync_mode"]
        incremental_by = self.data_sync_options["incremental_by"]
        if data_sync_mode == "incremental" and incremental_by == "timestamp":
            destination_data_dt = DeltaTable.forPath(self.spark, destination_table_full_path)
            source_data_df = self.spark.table(source_table_name)
            source_alias = "source"
            target_alias = "target"
            
            tableutil = TableUtil(destination_table_name, self.spark, self.debug)
            table_property_dict = tableutil.get_table_properties()
            destination_table_primarykey = table_property_dict["mdd.primaryKey"]
            if destination_table_primarykey is None or len(destination_table_primarykey) == 0:
                error_msg = f"table property '{table_property_pk}' has no value on table '{destination_table_name}'"
                self.logger.error(error_msg)
                raise Exception(error_msg)
            columns_join = destination_table_primarykey
            merge_join_condition = " AND ".join([f"{target_alias}.{col} = {source_alias}.{col}" for col in columns_join])
            (
                destination_data_dt.alias(target_alias)
                                    .merge(source = source_data_df.alias(source_alias), condition = merge_join_condition)
                                    .whenNotMatchedBySourceUpdate(condition = f"{target_alias}._source_name = '{source_table_name}' AND _deleted_by_source = false "
                                        ,set = {f"{target_alias}._deleted_by_source": "True"
                                            ,f"{target_alias}._record_timestamp": lit(current_timestamp())
                                            })
                                    .execute()
            )

        self.logger.info(f"{m_df.dataflow_type} end: {source_table_name} -> {destination_table_name}")

        # run table validators
        if metadata_validator_yml is not None and metadata_validator_yml != "":
            validator_table = TableValidator(metadata_validator_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            validator_table.validate(destination_table_name, destination_table_full_path)

        # run data patchers
        metadata_patcher_yml = m_df.patchers
        if metadata_patcher_yml is not None and metadata_patcher_yml != "":
            self.logger.info(f"patch start: {destination_table_name}")
            patcher_helper = PatcherHelper(destination_table_full_path, destination_table_name, metadata_patcher_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            patcher_helper.run()
            self.logger.info(f"patch end: {destination_table_name}")


        if self.debug: 
            self.logger.debug(f"function end: {function_name}")
    # function end: run


# In[ ]:


class Load_Dataflow:

    def __init__(self, metadata_dataflow_yml, metadata_environment_yml, data_sync_options, spark, logger, debug = False):
        function_name = "__init__"
        if debug:
            logger.debug(f"function begin: {function_name}")
            logger.debug(f"metadata_environment_yml: {metadata_environment_yml}")
            logger.debug(f"metadata_dataflow_yml: {metadata_dataflow_yml}")
            logger.debug(f"data_sync_options: {data_sync_options}")

        self.spark = spark
        self.debug = debug
        self.logger = logger

        # environment metadata
        self.metadata_environment = Metadata_Environment(metadata_environment_yml, debug)

        # dataflow metadata       
        self.metadata_dataflow = Metadata_Transform_Dataflow(metadata_dataflow_yml, debug) 
          
        # data sync options
        self.data_sync_options = data_sync_options

        if debug:
            logger.debug(f"function end: {function_name}")
    # function end: init 
    

    # execute the dataflow 
    def run(self):
        function_name = "run"
        if self.debug:
            self.logger.debug(f"function begin: {function_name}")
        
        m_en = self.metadata_environment
        m_df = self.metadata_dataflow

        # map schema holder to schema
        map_table_schema = lambda x: x.replace("<bronze>", m_en.destination_bronze_schema) \
                                    .replace("<silver>", m_en.destination_silver_schema) \
                                    .replace("<gold>", m_en.destination_gold_schema) 

        # get source table name
        source_lakehouse = m_en.destination_lakehouse
        source_table_schema = map_table_schema(m_df.source_table_schema)
        source_table_name = f"{source_table_schema}.{m_df.source_table_name}"
        source_table_full_name = f"{source_lakehouse}.{source_table_schema}.{m_df.source_table_name}"
        if self.debug:
            self.logger.debug(f"source_table_name: {source_table_name}")
            self.logger.debug(f"source_table_full_name: {source_table_full_name}")
        
        # get destination table name
        destination_lakehouse = m_en.destination_lakehouse
        destination_table_schema = map_table_schema(m_df.destination_table_schema)
        destination_table_name = f"{destination_table_schema}.{m_df.destination_table_name}"
        destination_table_full_name = f"{destination_lakehouse}.{destination_table_schema}.{m_df.destination_table_name}"
        destination_table_full_path = f"/{m_en.destination_lakehouse_guid}/Tables/{destination_table_schema}/{m_df.destination_table_name}"
        destination_write_mode = m_df.destination_write_mode
        metadata_validator_yml = m_df.validators
        destination_projected_sql = m_df.destination_projected_sql
        destination_write_options = m_df.destination_write_options
        if self.debug:
            self.logger.debug(f"destination_table_name: {destination_table_name}")
            self.logger.debug(f"destination_table_full_name: {destination_table_full_name}")
            self.logger.debug(f"destination_table_full_path: {destination_table_full_path}")
            self.logger.debug(f"destination_write_mode: {destination_write_mode}")
            self.logger.debug(f"metadata_validator_yml: {metadata_validator_yml}")
            self.logger.debug(f"destination_projected_sql: {destination_projected_sql}")
            self.logger.debug(f"destination_write_options: {destination_write_options}")

        # register the main source table
        property_name = "mdd.source.primary"
        tableutil = TableUtil(destination_table_name, self.spark, self.debug)
        tableutil.set_table_property_list(property_name, source_table_name)

        # get final data sync options generate by the data sync manifest
        data_sync_manifest = TableDataSyncManifest(self.spark, self.debug)
        data_sync_manifest_group_list = data_sync_manifest.get_data_sync_manifest(source_table_name, destination_table_name, self.data_sync_options)
        source_data_df = data_sync_manifest.source_data_df

        # loop the file groups, read, transform and write the data to destination
        transformers = m_df.transformers
        if self.debug:
            self.logger.debug(f"transformers: {transformers}")

        self.logger.info(f"{m_df.dataflow_type} start: {source_table_name} -> {destination_table_name}")
        data_sync_mode = self.data_sync_options["data_sync_mode"]
        data_sync_mode_final = data_sync_manifest.data_sync_mode_final
        if data_sync_mode != data_sync_mode_final:
            msg = f"data_sync_mode fallback: {data_sync_mode} -> {data_sync_mode_final}"
            self.logger.warning(msg)  

        total_rows = source_data_df.count()
        self.logger.info(f"total rows: {total_rows}")
        if total_rows > 0:
            self.logger.info(f"rows per batch: {self.data_sync_options['rows_per_batch']}")
            self.logger.info(f"total batches: {len(data_sync_manifest_group_list)}")
        
        schema_bronze = m_en.destination_bronze_schema
        schema_silver = m_en.destination_silver_schema
        schema_gold = m_en.destination_gold_schema
        i = 0
        for batch_timestamps in data_sync_manifest_group_list[:]:
            i += 1
            batch_data_df = source_data_df.filter((source_data_df._commit_timestamp >= batch_timestamps[0]) & (source_data_df._commit_timestamp <= batch_timestamps[1]))
            self.logger.info(f"process batch {i}: {batch_timestamps[0].strftime('%Y-%m-%d %H:%M:%S.%f')} - {batch_timestamps[1].strftime('%Y-%m-%d %H:%M:%S.%f')}")
            self.logger.info(f"total rows: {batch_data_df.count()}")
                
            # if no data, skip
            if batch_data_df.isEmpty():
                self.logger.warning(f"batch_data_df: no data")
                continue

            # transform
            transformerhelper = TransformerHelper(destination_table_name, batch_data_df, transformers, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            batch_data_transformed_df = transformerhelper.run().withColumn("_source_name", lit(source_table_name))

            # write
            self.logger.info(f"write start")
            datawriter = GoldDataWriter(batch_data_transformed_df, destination_table_full_path, destination_table_name, destination_write_mode, \
                destination_write_options, destination_projected_sql, metadata_validator_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            datawriter.write()
            self.logger.info(f"write end")
        # end for

        # soft-delete the deleted rows if the data is incremental sync-ed by timestmap
        data_sync_mode = self.data_sync_options["data_sync_mode"]
        incremental_by = self.data_sync_options["incremental_by"]
        if data_sync_mode == "incremental" and incremental_by == "timestamp":
            destination_data_dt = DeltaTable.forPath(self.spark, destination_table_full_path)
            source_data_df = self.spark.table(source_table_name)
            source_alias = "source"
            target_alias = "target"
            
            tableutil = TableUtil(destination_table_name, self.spark, self.debug)
            table_property_dict = tableutil.get_table_properties()
            destination_table_primarykey = table_property_dict["mdd.primaryKey"]
            if destination_table_primarykey is None or len(destination_table_primarykey) == 0:
                error_msg = f"table property '{table_property_pk}' has no value on table '{destination_table_name}'"
                self.logger.error(error_msg)
                raise Exception(error_msg)
            columns_join = destination_table_primarykey
            merge_join_condition = " AND ".join([f"{target_alias}.{col} = {source_alias}.{col}" for col in columns_join])
            (
                destination_data_dt.alias(target_alias)
                                    .merge(source = source_data_df.alias(source_alias), condition = merge_join_condition)
                                    .whenNotMatchedBySourceUpdate(condition = f"{target_alias}._source_name = '{source_table_name}' AND _deleted_by_source = false "
                                        ,set = {f"{target_alias}._deleted_by_source": "True"
                                            ,f"{target_alias}._record_timestamp": lit(current_timestamp())
                                            })
                                    .execute()
            )
            
        self.logger.info(f"{m_df.dataflow_type} end: {source_table_name} -> {destination_table_name}")

        # run table validators
        if metadata_validator_yml is not None and metadata_validator_yml != "":
            validator_table = TableValidator(metadata_validator_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            validator_table.validate(destination_table_name, destination_table_full_path)

        # run data patchers
        metadata_patcher_yml = m_df.patchers
        if metadata_patcher_yml is not None and metadata_patcher_yml != "":
            self.logger.info(f"patch start: {destination_table_name}")
            patcher_helper = PatcherHelper(destination_table_full_path, destination_table_name, metadata_patcher_yml, schema_bronze, schema_silver, schema_gold, self.spark, self.debug)
            patcher_helper.run()
            self.logger.info(f"patch end: {destination_table_name}")

        if self.debug: 
            self.logger.debug(f"function end: {function_name}")
    # function end: run

