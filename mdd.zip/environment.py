#!/usr/bin/env python
# coding: utf-8

# ## environment
# 
# New notebook

# In[ ]:


import yaml
from pathlib import Path

class _Environment:
    """Singleton environment config that auto-loads from YAML."""

    def __init__(self):
        self._loaded = False

    def _load(self):
        # TODO: update this path if metadata deployed in a different folder
        self.root_path_metadata = "/lakehouse/default/Files/mdd/metadata/"


        config_path = Path(f"{self.root_path_metadata}environment.yml")
        if not config_path.exists():
            raise FileNotFoundError(f"Missing config: {config_path}")

        with open(config_path, "r") as f:
            config = yaml.safe_load(f)

        for key, value in config.items():
            setattr(self, key, value)

        self._loaded = True

    def __getattr__(self, item):
        if not self._loaded:
            self._load()
        return self.__dict__.get(item)

# This is the public interface
Environment = _Environment()

