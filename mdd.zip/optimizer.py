#!/usr/bin/env python
# coding: utf-8

# ## optimizer
# 
# New notebook

# In[ ]:


import re
import os
import math
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Union, Tuple
from concurrent.futures import ThreadPoolExecutor
from pyspark.sql.types import StructType, StructField, StringType, LongType, TimestampType
from pyspark.sql import DataFrame, Row, SparkSession
import pyspark.sql.functions as F
from notebookutils import mssparkutils
from io import BytesIO
import pyarrow.parquet as pq


class Optimizer():
    @staticmethod
    def get_lakehouse_name(spark: SparkSession) -> str:
        df = spark.sql("SHOW DATABASES").limit(1)
        db_namespace = df.collect()[0][0]
        db_namespace_list = db_namespace.split(".")

        if len(db_namespace_list) == 1:
            lakehouse_name = db_namespace_list[0]
        else:
            lakehouse_name = db_namespace_list[1]

        return lakehouse_name
            
    @staticmethod
    def get_lakehouse_id() -> str:
        location = mssparkutils.fs.ls("Tables/")[0].path

        match = re.search(r"onelake\.dfs\.fabric\.microsoft\.com/([^/]+)/Tables", location)
        if not match:
            raise ValueError(f"Could not extract Lakehouse ID from location URI: {location}")

        return match.group(1)

    @staticmethod
    def get_schemas(spark: SparkSession) -> List[str]:
        lakehouse_name = Optimizer.get_lakehouse_name(spark)

        df = spark.sql("SHOW DATABASES")

        # not schema supported
        if df.count() == 1 and df.collect()[0][0] == lakehouse_name:
            return []

        col_name = df.columns[0]
        schemas_namespace = df.select(col_name).rdd.flatMap(lambda x: x).collect()
        schemas = [schema.split(".")[2] for schema in schemas_namespace]

        return schemas

    @staticmethod
    def get_abfs_location(spark: SparkSession, table_name: str) -> str:
        location = spark.sql(f"DESCRIBE DETAIL {table_name}").select("location").collect()[0][0]

        return location

    @staticmethod
    def get_tables(spark: SparkSession) -> List[str]:
        """
        List all table names in a given lakehouse by reading directory names under /<lakehouse_id>/Tables.

        Args:
            lakehouse_name (str): The lakehouse name.

        Returns:
            List[str]: Sorted list of table names (directory names).
        """
        schemas = Optimizer.get_schemas(spark)
        tables = []
        if len(schemas) == 0:
            tables_base_path = f"Tables/"
            table_dirs = mssparkutils.fs.ls(tables_base_path)
            tables.extend([entry.name.rstrip("/") for entry in table_dirs if entry.isDir])
        else:
            for schema in schemas:
                tables_base_path = f"Tables/{schema}/"
                table_dirs = mssparkutils.fs.ls(tables_base_path)
                tables.extend([f"`{schema}`.`{entry.name.rstrip('/')}`" for entry in table_dirs if entry.isDir])

        return sorted(tables, key=str.lower)

    @staticmethod
    def get_table_history(spark: SparkSession, table_name: str) -> dict:
        """
        Returns a dictionary with:
        - zorderColumns: comma-separated string if ZORDER exists, else "None"
        - zorderTimestamp: timestamp of last ZORDER, else "None"
        - version: latest version of the Delta table (always returned)

        Example:
        {
            "zorderColumns": "col1,col2",
            "zorderTimestamp": "2025-05-31 12:00:00",
            "version": "42"
        }
        """
        df = spark.sql(f"DESCRIBE HISTORY {table_name} LIMIT 1")

        if df.count() == 0:
            raise ValueError(f"No history found for table: {table_name}")

        latest_version_row = df.orderBy(F.col("version").desc()).first()
        latest_version = str(latest_version_row["version"])
        latest_timestamp = str(latest_version_row["timestamp"])

        # Check for most recent optimization
        optimize_df = df.filter(
            "operation = 'OPTIMIZE'"
        )

        if optimize_df.count() == 0:
            return {
                "version": latest_version,
                "timestamp": latest_timestamp,
                "optimizeVersion": None,
                "optimizeTimestamp": None,
                "zorderColumns": None,
            }

        latest_optimize = optimize_df.orderBy(F.col("timestamp").desc()).first()
        optimize_version = str(latest_optimize["version"])
        optimize_timestamp = str(latest_optimize["timestamp"])
        zorder_cols_str = (
            latest_optimize["operationParameters"]["zOrderBy"].strip("[]").replace('"', '')
            if "zOrderBy" in latest_optimize["operationParameters"]
            else None
        )
        return {
            "version": latest_version,
            "timestamp": latest_timestamp,
            "optimizeVersion": optimize_version,
            "optimizeTimestamp": optimize_timestamp,
            "zorderColumns": zorder_cols_str,
        }

    @staticmethod
    def get_table_schema(spark: SparkSession, table_name: str) -> List[str]:
        try:
            df = spark.table(table_name)
            return [f"{field.name}:{field.dataType.simpleString()}" for field in df.schema.fields]
        except Exception:
            return []

    @staticmethod
    def get_table_partition_columns(spark: SparkSession, table_name: str) -> list:
        """
        Returns the list of partition columns for a Delta table.
        If lakehouse_name is provided, it uses the full path.
        If not, it assumes the table is in the current lakehouse context.
        """    
        sql_cmd = f"DESCRIBE DETAIL {table_name}"
        details = spark.sql(sql_cmd).collect()
        
        if not details:
            raise ValueError(f"Table not found: {table_name}")
        
        return details[0]["partitionColumns"]

    @staticmethod
    def get_table_files(spark: SparkSession, table_name: str) -> Dict[str, DataFrame]:
        lakehouse_id = Optimizer.get_lakehouse_id()
        table_full_path = f"/{lakehouse_id}/Tables/{table_name.replace('.', '/').replace('`', '')}"
        #print(table_full_path)

        try:
            df_log = spark.read.option("mergeSchema", "true") \
                .json(f"{table_full_path}/_delta_log/*.json")
        except Exception as e:
            raise RuntimeError(f"Failed to read delta log for table {table_full_path}: {e}")

        # Define schema for the 'stats' JSON field
        stats_schema = StructType([StructField("numRecords", LongType(), True)])

        if "add" in df_log.columns:
            # Extract the 'add' struct safely
            add_fields = df_log.select("add.*").columns
            if "stats" in add_fields:
                df_log = df_log.withColumn("add_stats", F.col("add").getField("stats"))
            else:
                df_log = df_log.withColumn("add_stats", F.lit(None).cast("string"))

            df_log = (
                df_log.withColumn("add_path", F.col("add").getField("path"))
                    .withColumn("add_size", F.col("add").getField("size"))
                    .withColumn("add_mod_time", F.col("add").getField("modificationTime"))
            )

            # Build the final DataFrame
            df_files_added = (
                df_log.filter(F.col("add_path").isNotNull())
                .withColumn("numRecords", 
                    F.when(F.col("add_stats").isNotNull(),
                        F.from_json(F.col("add_stats"), stats_schema)["numRecords"])
                )
                .withColumn("modificationTime", 
                    F.from_unixtime(F.col("add_mod_time") / 1000).cast(TimestampType()))
                .select(
                    F.col("add_path").alias("file"),
                    F.col("add_size").alias("size"),
                    "numRecords",
                    "modificationTime"
                )
            )
        else:
            # Return empty DataFrame with expected schema
            df_files_added = spark.createDataFrame(
                [],
                schema="file string, size long, numRecords long, modificationTime timestamp"
            )


        if "remove" in df_log.columns:
            df_files_removed = (
                df_log.filter(F.col("remove").isNotNull())
                .selectExpr(
                    "remove.path as file", 
                    "remove.size as size", 
                    "remove.deletionTimestamp as deletionTimestamp"
                )
                .withColumn("deletionTimestamp", F.from_unixtime(F.col("deletionTimestamp") / 1000))
            )
        else:
            df_files_removed = spark.createDataFrame(
                [], schema="file string, size long, deletionTimestamp timestamp"
            )

        def extract_partition_path(file_path: str) -> str:
            """
            Extracts the partition path (e.g., 'PartitionId=2021/Region=CA') from a file path.
            """
            # Get directory portion
            path_parts = Path(file_path).parts
            # Find parts that look like partition key=value
            partition_parts = [part for part in path_parts if '=' in part]
            return '/'.join(partition_parts)

        extract_partition_udf = F.udf(extract_partition_path, StringType())
        df_files_active = (
            df_files_added.join(df_files_removed, on="file", how="left_anti")
            .withColumn("partition", extract_partition_udf("file"))
        )

        return {
            "active": df_files_active,
            "removed": df_files_removed
        }

    @staticmethod
    def get_table_files_metadata(spark: SparkSession, table_name: str, temp_path: str = "/tmp/tmp.parquet"):
        location = Optimizer.get_abfs_location(spark, table_name)
        table_files = Optimizer.get_table_files(spark, table_name)
        df_active = table_files["active"]
        df_removed = table_files["removed"]
        active_files = df_active.select("file").rdd.flatMap(lambda x: x).collect()

        for file in active_files:
            file_path = f"{location}/{file}"
            print(f"\nfile: {file_path}")

            mssparkutils.fs.cp(
                file_path,
                f"file:{temp_path}"
            )

            pf = pq.ParquetFile(temp_path)
            #print("schema: ")
            #print(pf.schema)
            print("metadata: ")
            print(pf.metadata)

            # inspect row groups individually
            for i in range(pf.num_row_groups):
                rg = pf.metadata.row_group(i)
                print(f"\nRow Group {i} metadata:")
                print(rg)

    @staticmethod
    def get_table_files_stats(spark: SparkSession, table_name: str) -> DataFrame:
        table_files = Optimizer.get_table_files(spark, table_name)
        df_active = table_files["active"]
        #display(df_active)

        df_partition_stats = (
            df_active.selectExpr(
                f"'{table_name}' as tableName",
                "file",
                "numRecords",
                "cast(size/1024 as int) as sizeInKB",
                "partition",
                "sum(numRecords) over (partition by partition) as numRecordsByPartition",
                "cast((sum(size) over (partition by partition))/1024 as int) as sizeInKBByPartition",
                "sum(numRecords) over () as numRecordsByTable",
                "cast((sum(size) over ())/1024 as int) as sizeInKBByTable"
            )
            .withColumn("sizePercentByPartition", F.col("sizeInKBByPartition")/F.col("sizeInKBByTable"))
            .withColumn("sizePercentByFile", F.col("sizeInKB")/F.col("sizeInKBByTable"))
        )
        #display(df_partition_stats)

        return df_partition_stats

    @staticmethod
    def get_table_stats(spark: SparkSession, table_name: str) -> Optional[Dict]:
        print(f"Retrieving stats for table {table_name}......")
        try:
            table_files = Optimizer.get_table_files(spark, table_name)
            df_files_active = table_files["active"]
            df_files_removed = table_files["removed"]

            # table-level stats
            df_files_active_stats = (
                df_files_active
                .withColumn("tableName", F.lit(table_name))
                .groupBy("tableName")
                .agg(
                    F.count("*").alias("numFiles"),
                    F.sum("numRecords").alias("numRecords"),
                    (F.sum("size") / 1024).cast("int").alias("sizeInKB"),
                    (F.sum("size") / 1024 / F.count("*")).cast("int").alias("sizeInKBAvg"),
                    (F.max("size") / 1024).cast("int").alias("sizeInKBMax"),
                    (F.min("size") / 1024).cast("int").alias("sizeInKBMin"),
                    F.max("modificationTime").alias("modificationTimeMax"),
                    F.min("modificationTime").alias("modificationTimeMin"),
                    F.countDistinct("partition").alias("numPartitions")
                )
            )

            # Per-partition stats
            df_files_partition_stats = (
                df_files_active
                .groupBy("partition")
                .agg(
                    F.count("*").alias("numFiles"),
                    F.sum("numRecords").alias("numRecords"),
                    (F.sum("size") / 1024).cast("int").alias("sizeInKB"),
                    F.max("modificationTime").alias("modificationTime")
                )
            )

            df_partition_summary = (
                df_files_partition_stats
                .agg(
                    F.max("numFiles").alias("numFilesMaxByPartition"),
                    F.min("numFiles").alias("numFilesMinByPartition"),
                    F.max("numRecords").alias("numRecordsMaxByPartition"),
                    F.min("numRecords").alias("numRecordsMinByPartition"),
                    F.max("sizeInKB").alias("sizeInKBMaxByPartition"),
                    F.min("sizeInKB").alias("sizeInKBMinByPartition"),
                    F.max("modificationTime").alias("modificationTimeMaxByPartition"),
                    F.min("modificationTime").alias("modificationTimeMinByPartition")
                )
                .withColumn("tableName", F.lit(table_name))
            )


            df_files_inactive_stats = (
                df_files_removed
                .withColumn("tableName", F.lit(table_name))
                .groupBy("tableName")
                .agg(
                    F.count("*").alias("deletionNumFiles"),
                    (F.sum("size") / 1024).cast("int").alias("deletionSizeInKB"),
                    F.max("deletionTimestamp").alias("deletionTimestampMax"),
                    F.min("deletionTimestamp").alias("deletionTimestampMin")
                )
            )

            result = (
                df_files_active_stats
                    .join(df_partition_summary, "tableName", "left")
                    .join(df_files_inactive_stats, "tableName", "left")

            )
            #display(result)

            # get partition columns
            partition_cols = Optimizer.get_table_partition_columns(spark, table_name)
            partition_cols_str = ", ".join(partition_cols)
            #print(partition_cols_str)

            # get zorder and version from table history
            table_history = Optimizer.get_table_history(spark, table_name)


            rows = result.take(1)
            if rows:
                row = rows[0]
                return {
                    "tableName": row["tableName"],
                    "version": int(table_history["version"]),
                    "timestamp": str(table_history["timestamp"]),
                    "numFiles": row["numFiles"],
                    "numRecords": row["numRecords"],
                    "sizeInKB": row["sizeInKB"],
                    "sizeInKBAvg": row["sizeInKBAvg"],
                    "sizeInKBMax": row["sizeInKBMax"],
                    "sizeInKBMin": row["sizeInKBMin"],
                    "modificationTimeMax": str(row["modificationTimeMax"]),
                    "modificationTimeMin": str(row["modificationTimeMin"]),

                    "optimizeVersion": table_history["optimizeVersion"],
                    "optimizeTimestamp": str(table_history["optimizeTimestamp"]),
                    "zorderColumns": table_history["zorderColumns"],

                    "partitionColumns": partition_cols_str,
                    "numPartitions": row["numPartitions"],        
                    "numFilesMaxByPartition": row["numFilesMaxByPartition"],
                    "numFilesMinByPartition": row["numFilesMinByPartition"],
                    "numRecordsMaxByPartition": row["numRecordsMaxByPartition"],
                    "numRecordsMinByPartition": row["numRecordsMinByPartition"],
                    "sizeInKBMaxByPartition": row["sizeInKBMaxByPartition"],
                    "sizeInKBMinByPartition": row["sizeInKBMinByPartition"],
                    "modificationTimeMaxByPartition": str(row["modificationTimeMaxByPartition"]),
                    "modificationTimeMinByPartition": str(row["modificationTimeMinByPartition"]),

                    "deletionNumFiles": row["deletionNumFiles"],
                    "deletionSizeInKB": row["deletionSizeInKB"],
                    "deletionTimestampMax": str(row["deletionTimestampMax"]),
                    "deletionTimestampMin": str(row["deletionTimestampMin"])
                }

            return None

        except Exception as e:
            print(f"Error processing {table_name}: {str(e)[:200]}")
            return None

    @staticmethod
    def get_tables_stats(spark: SparkSession, tables: Optional[List[str]] = None, max_workers: int = 8) -> DataFrame:
        """
        Get statistics for tables in a Lakehouse using parallel processing.

        Args:
            lakehouse_name: Name of the Lakehouse.
            tables: Optional list of specific tables to analyze. If None, analyzes all tables.
            max_workers: Number of threads to use for parallelism.

        Returns:
            DataFrame with table statistics.
        """
        result_schema = StructType([
            StructField("tableName", StringType()),
            StructField("version", LongType()),
            StructField("timestamp", TimestampType()),
            StructField("numFiles", LongType()),
            StructField("numRecords", LongType()),
            StructField("sizeInKB", LongType()),
            StructField("sizeInKBAvg", LongType()),
            StructField("sizeInKBMax", LongType()),
            StructField("sizeInKBMin", LongType()),
            StructField("modificationTimeMax", TimestampType()),
            StructField("modificationTimeMin", TimestampType()),

            StructField("optimizeVersion", LongType()),
            StructField("optimizeTimestamp", TimestampType()),
            StructField("zorderColumns", StringType()),

            StructField("partitionColumns", StringType()),
            StructField("numPartitions", LongType()),
            StructField("numFilesMaxByPartition", LongType()),
            StructField("numFilesMinByPartition", LongType()),
            StructField("numRecordsMaxByPartition", LongType()),
            StructField("numRecordsMinByPartition", LongType()),
            StructField("sizeInKBMaxByPartition", LongType()),
            StructField("sizeInKBMinByPartition", LongType()),
            StructField("modificationTimeMaxByPartition", TimestampType()),
            StructField("modificationTimeMinByPartition", TimestampType()),

            StructField("deletionNumFiles", LongType()),
            StructField("deletionSizeInKB", LongType()),
            StructField("deletionTimestampMax", TimestampType()),
            StructField("deletionTimestampMin", TimestampType())
        ])

        table_list = tables if tables is not None else Optimizer.get_tables(spark)

        def parse_result(result: dict) -> Optional[Row]:
            if not result:
                return None
            try:
                return Row(
                    tableName=result.get("tableName"),
                    version=result.get("version"),
                    timestamp=datetime.fromisoformat(result.get("timestamp")),
                    numFiles=result.get("numFiles"),
                    numRecords=result.get("numRecords"),
                    sizeInKB=result.get("sizeInKB"),
                    sizeInKBAvg=result.get("sizeInKBAvg"),
                    sizeInKBMax=result.get("sizeInKBMax"),
                    sizeInKBMin=result.get("sizeInKBMin"),
                    modificationTimeMax = (
                        datetime.fromisoformat(result["modificationTimeMax"])
                        if result.get("modificationTimeMax") not in [None, "None"]
                        else None
                    ),
                    modificationTimeMin = (
                        datetime.fromisoformat(result["modificationTimeMin"])
                        if result.get("modificationTimeMin") not in [None, "None"]
                        else None
                    ),

                    optimizeVersion = (
                        int(result.get("optimizeVersion")) 
                        if result.get("optimizeVersion") not in (None, "None") 
                        else None
                    ),
                    optimizeTimestamp = (
                        datetime.fromisoformat(result["optimizeTimestamp"])
                        if result.get("optimizeTimestamp") not in [None, "None"]
                        else None
                    ),
                    zorderColumns = (
                        result.get("zorderColumns") 
                        if result.get("zorderColumns") not in (None, "None") 
                        else None
                    ),


                    partitionColumns=result.get("partitionColumns"),
                    numPartitions=result.get("numPartitions"),
                    numFilesMaxByPartition=result.get("numFilesMaxByPartition"),
                    numFilesMinByPartition=result.get("numFilesMinByPartition"),
                    numRecordsMaxByPartition=result.get("numRecordsMaxByPartition"),
                    numRecordsMinByPartition=result.get("numRecordsMinByPartition"),
                    sizeInKBMaxByPartition=result.get("sizeInKBMaxByPartition"),
                    sizeInKBMinByPartition=result.get("sizeInKBMinByPartition"),
                    modificationTimeMaxByPartition = (
                        datetime.fromisoformat(result["modificationTimeMaxByPartition"])
                        if result.get("modificationTimeMaxByPartition") not in [None, "None"]
                        else None
                    ),
                    modificationTimeMinByPartition = (
                        datetime.fromisoformat(result["modificationTimeMinByPartition"])
                        if result.get("modificationTimeMinByPartition") not in [None, "None"]
                        else None
                    ),

                    deletionNumFiles=result.get("deletionNumFiles"),
                    deletionSizeInKB=result.get("deletionSizeInKB"),
                    deletionTimestampMax = (
                        datetime.fromisoformat(result["deletionTimestampMax"])
                        if result.get("deletionTimestampMax") not in [None, "None"]
                        else None
                    ),
                    deletionTimestampMin = (
                        datetime.fromisoformat(result["deletionTimestampMin"])
                        if result.get("deletionTimestampMin") not in [None, "None"]
                        else None
                    )
                )
            except Exception as e:
                print(f"Error parsing result: {e}")
                return None

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            raw_results = list(executor.map(lambda t: Optimizer.get_table_stats(spark, t), table_list))

        parsed_results = list(filter(None, map(parse_result, raw_results)))

        return spark.createDataFrame(parsed_results, result_schema) if parsed_results else spark.createDataFrame([], result_schema)


    @staticmethod
    def optimize(
        spark: SparkSession,
        table_name: str,
        target_file_max_size_mb: int = 128,
        zorder_cols: Optional[List[str]] = None,
    ) -> Dict[str, Union[str, int, float, bool, List[str], Dict]]:

        action_plan = {
            "table": table_name,
            "status": "pending"
        }

        try:

            stats = Optimizer.get_table_stats(spark, table_name)
            if not stats:
                raise ValueError("get_table_stats() failed or returned no data.")

            total_size_kb = stats["sizeInKB"]
            max_file_size_kb = stats["sizeInKBMax"]
            target_file_size_bytes = target_file_max_size_mb * 1024 * 1024
            before_row_count = stats["numRecords"]

            stats.pop("tableName")
            action_plan.update({
                "target_file_size_mb": target_file_max_size_mb,
                "zorder_cols": zorder_cols,
                "stats_before": stats
            })

            print(f"Optimizing table {table_name}......")

            #TODO: file size and data change flag are not support by MS Fabric yet
            #spark.conf.set("spark.sql.files.maxFileSize", f"{target_file_size_bytes}")
            #spark.conf.set("spark.sql.delta.properties.defaults.dataChange", "false")

            optimize_sql = f"OPTIMIZE {table_name} "
            if zorder_cols:
                optimize_sql += f" ZORDER BY (`{'`, `'.join(zorder_cols)}`)"
            spark.sql(optimize_sql)

            post_stats = Optimizer.get_table_stats(spark, table_name)
            after_row_count = post_stats["numRecords"] if post_stats else None

            post_stats.pop("tableName")
            action_plan.update({
                "stats_after": post_stats,
            })

            if after_row_count is not None and before_row_count is not None:
                if after_row_count != before_row_count:
                    rollback_version = before_version
                    spark.sql(f"RESTORE TABLE {table_name} TO VERSION AS OF {rollback_version}")
                    action_plan.update({
                        "status": "rolled_back",
                        "rollback_reason": f"Row count mismatch: before={before_row_count}, after={after_row_count}",
                        "rolled_back_to_version": rollback_version
                    })
                    return action_plan
                else:
                    spark.sql(f"vacuum {table_name}")

            action_plan["status"] = "success"
            return action_plan

        except Exception as e:
            action_plan["status"] = "failed"
            action_plan["error_message"] = str(e)
            return action_plan



