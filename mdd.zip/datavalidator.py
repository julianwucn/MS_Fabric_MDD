#!/usr/bin/env python
# coding: utf-8

# ## datavalidator
# 
# New notebook

# In[1]:


import yaml
import os
import logging
from datetime import datetime
from typing import Optional
from functools import reduce
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.types import *

from env.mdd.mddutils import *
from env.mdd.metadata import *
from env.mdd.logger import *
from env.mdd.environment import *

@DecoratorUtil.add_logger()
class DataValidator:
    def __init__(self, 
        table_name: str, 
        spark: SparkSession = None, 
        logger: Logger = None,
        debug: bool = False, 
        validation_run_id: str = "validation_123",
        task_run_id: str = "task_123",
        job_run_id: str = "job_123"
    ):
        self.table_name = table_name
        self.spark = spark or SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
        self.debug = debug
        self.task_run_id = task_run_id
        self.job_run_id = job_run_id
        self.validation_run_id = validation_run_id

        self.expectations = []
        self.violations = {}
        self.df = None

    @DecoratorUtil.log_function()
    def expect(self, df: DataFrame, source: str, name: str, condition: str, action: str = "none", active: bool = True):
        if not active:
            if not source:
                self.df = df
            return
            
        if self.debug:
            self.logger.debug(f"expectation: {name} - {action}")

        starttimestamp = datetime.now()

        try:
            failed_df = df.filter(f"NOT ({condition})")
        except Exception as e:
            raise Exception(f"Expectation '{name}' incorrect condition '{condition}': {e}") 

        source_count = df.count()
        failed_count = failed_df.count()
        passed = failed_count == 0

        if not passed:
            self.logger.info(f"validate expectation: {name} - {failed_count}/{source_count} rows violated")
            if action == "drop" and not source:
                df = df.filter(condition)
        else:
            self.logger.info(f"validate expectation: {name} - passed")

        if not passed:
            failed_df = failed_df.withColumn("expectation", lit(name)).withColumn("action", lit(action))
            self.violations[name] = failed_df

        endtimestamp = datetime.now()

        self.expectations.append({
            "source": source,
            "source_count": source_count,
            "expectation_name": name,
            "expectation_condition": condition,
            "expectation_action": action,
            "expectation_passed": passed,
            "expectation_failedcount": failed_count,
            "expectation_start_timestamp": starttimestamp,
            "expectation_end_timestamp": endtimestamp
        })

        if not source:
            self.df = df

    @DecoratorUtil.log_function()
    def assert_expectations(self):
        failures = [e for e in self.expectations if e["expectation_action"] == "fail"  and not e["expectation_passed"]]
        for e in failures:
            self.logger.error(f"[FAIL] {e['expectation_name']} failed: {e['expectation_failedcount']} rows")

        if failures:
            raise Exception(f"{len(failures)} expectations with action=fail did not pass.")

    @DecoratorUtil.log_function()
    def summary(self):
        schema = """
            source string,
            source_count long,
            expectation_name string, 
            expectation_condition string, 
            expectation_action string, 
            expectation_passed boolean, 
            expectation_failedcount long, 
            expectation_start_timestamp timestamp, 
            expectation_end_timestamp timestamp"""
        return self.spark.createDataFrame(self.expectations, schema)

    @DecoratorUtil.log_function()
    def get_df(self):
        return self.df

    @DecoratorUtil.log_function()
    def save_summary(self):
        df_summary = self.summary()
        
        JobUtil.table_validation_update(
            self.table_name
            ,df_summary
            ,self.validation_run_id
            ,self.task_run_id
            ,self.job_run_id
        )

    @DecoratorUtil.log_function()
    def export_violations(self, format: str = "parquet"):
        path = f"{Environment.destination['destination_table_validation_export_path']}/{self.table_name}/{self.validation_run_id}"
        for key in self.violations:
            full_path = f"{path}/{key}/"
            df = self.violations[key]
            df.write.mode("overwrite").option("header", True).format(format).save(full_path)

    @staticmethod
    def validate_df(
        df: Optional[DataFrame],
        table_name: str,
        yaml_path: str, 
        spark: SparkSession,
        logger: Logger, 
        task_run_id: str = "task_123",
        task_start_timestamp: TimestampType = None,
        job_run_id: str = "job_123"
    ) -> DataFrame:
        if not df:
            raise ValueError("The input dataframe is None")
            
        metadata_validator = Metadata_Validator(yaml_path, logger)
        config = metadata_validator.metadata

        if not config.get("active", True):
            return df

        debug = config.get("debug", False)

        #validation_start_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        validation_run_id = f"validation_{task_start_timestamp}"
        validator = DataValidator(table_name=table_name, spark=spark, logger=logger, debug=debug, 
                                    validation_run_id=validation_run_id, task_run_id=task_run_id, job_run_id=job_run_id)

        validated_df = df
        expectations = config.get("expectations", []) 
        for expectation in expectations:
            if not expectation.get("active", True):
                continue

            query_or_table = expectation.get("query", "")
            if query_or_table and "vw_temp_source_data_uuid" not in query_or_table.lower():
                continue

            action = expectation.get("action", "none") or "none"
            if query_or_table and action == "drop":
                msg = f"action '{action}' does not support for the given query"
                logger.error(msg)
                raise ValueError(msg)

            table_df = validated_df
            if query_or_table:
                if "vw_temp_source_data_uuid" not in query_or_table.lower():
                    continue
                else:
                    # generate a unique temp view name
                    vw_temp_source_data_uuid = f"vw_temp_source_data_{uuid.uuid4().hex}"
                    query_or_table_view = query_or_table.replace("vw_temp_source_data_uuid", vw_temp_source_data_uuid)

                    validated_df.createOrReplaceTempView(vw_temp_source_data_uuid)
                    try:
                        if str(query_or_table_view).strip().lower().startswith("select"):
                            table_df = spark.sql(query_or_table_view)
                        else:
                            table_df = spark.table(query_or_table_view)
                    except Exception as e:
                        logger.error(f"Failed to load source {query_or_table_view}: {e}")
                        raise e

            validator.expect(
                df=table_df,
                source=query_or_table,
                name=expectation["name"],
                condition=expectation["condition"],
                action=action,
                active=True
            )

            validated_df = validator.get_df()

        validator.save_summary()
        validator.export_violations()
        validator.assert_expectations()
            
        return validated_df


    @staticmethod
    def validate_query(
        table_name: str,
        yaml_path: str, 
        spark: SparkSession,
        logger: Logger, 
        task_run_id: str = "task_123",
        task_start_timestamp: TimestampType = None,
        job_run_id: str = "job_123"
    ):
            
        metadata_validator = Metadata_Validator(yaml_path, logger)
        config = metadata_validator.metadata

        if not config.get("active", True):
            return

        debug = config.get("debug", False)

        #validation_start_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        validation_run_id = f"validation_{task_start_timestamp}"
        validator = DataValidator(table_name=table_name, spark=spark, logger=logger, debug=debug, 
                                    validation_run_id=validation_run_id, task_run_id=task_run_id, job_run_id=job_run_id)

        expectations = config.get("expectations", []) 
        for expectation in expectations:
            if not expectation.get("active", True):
                continue

            query_or_table = expectation.get("query", "")
            if not query_or_table or "vw_temp_source_data_uuid" in query_or_table.lower():
                continue

            action = expectation.get("action", "none") or "none"
            if query_or_table and action == "drop":
                msg = f"action '{action}' does not support for the given query"
                logger.error(msg)
                raise ValueError(msg)

            try:
                if str(query_or_table).strip().lower().startswith("select"):
                    table_df = spark.sql(query_or_table)
                else:
                    table_df = spark.table(query_or_table)
            except Exception as e:
                logger.error(f"Failed to load source {query_or_table}: {e}")
                raise e

            validator.expect(
                df=table_df,
                source=query_or_table,
                name=expectation["name"],
                condition=expectation["condition"],
                action=action,
                active=True
            )

        validator.save_summary()
        validator.export_violations()
        validator.assert_expectations()
     

