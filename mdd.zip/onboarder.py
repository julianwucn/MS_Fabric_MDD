#!/usr/bin/env python
# coding: utf-8

# ## onboarder
# 
# New notebook

# In[ ]:


# The command is not a standard IPython magic command. It is designed for use within Fabric notebooks only.
# %run install_pub_packages


# In[ ]:


# Use the 2 magic commands below to reload the modules if your module has updates during the current session. You only need to run the commands once.
# %load_ext autoreload
# %autoreload 2
# import
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from delta import *
from delta.tables import *
import datetime as mdt
import os
import re
import sys
import json
import logging
import notebookutils

from inspect import isclass
from pkgutil import iter_modules
from pathlib import Path

from env.mdd.metadata import *
from env.mdd.datamanifest import *
from env.mdd.datareader import *
from env.mdd.datawriter import *
from env.mdd.datavalidator import *
from env.mdd.mddutils import *
from env.mdd.environment import Environment

# dynamically import the data readers
from importlib import import_module
import env.mdd.datareaders as datareaders
for module_name in datareaders.__all__:
    import_module(f"{datareaders.__name__}.{module_name}")

 


# In[ ]:


@DecoratorUtil.add_logger()
class Onboarder:

    def __init__(self, metadata_dataflow_yml, data_sync_options, spark, debug = False, job_name = "job_123", job_start_timestamp = None, task_name = "task_123", task_start_timestamp = None):

        self.spark = spark
        self.debug = debug

        self.job_run_id = f"{job_name}_{job_start_timestamp}"
        self.task_run_id = f"{task_name}_{task_start_timestamp}"
        self.task_start_timestamp = task_start_timestamp

        # dataflow metadata       
        self.metadata_dataflow = Metadata_Onboarding_Dataflow(metadata_dataflow_yml, self.logger, debug) 
          
        # data sync options
        self.data_sync_options = data_sync_options    

    # function end: init 
    

    # execute the dataflow 
    @DecoratorUtil.log_function()
    def run(self):
        source_data_root_path = Environment.source["source_data_root_path"]
        destination_lakehouse = Environment.destination["destination_lakehouse"]
        destination_lakehouse_guid = Environment.destination["destination_lakehouse_guid"]

        m_df = self.metadata_dataflow

        # reader metadata
        source_data_format = m_df.source_data_format
        source_data_path = f"{source_data_root_path}{m_df.source_data_relative_path}"
        source_file_name_regex = m_df.source_file_name_regex
        source_file_cleanup = m_df.source_file_cleanup
        source_data_read_options = m_df.Source_data_read_options
        source_data_schema = m_df.source_data_schema

        # writer metadata
        destination_projected_sql = m_df.destination_projected_sql
        destination_write_mode = m_df.destination_write_mode
        destination_write_options = m_df.destination_write_options
        destination_primarykey = m_df.destination_primarykey
        destination_deduplication_expr = m_df.destination_deduplication_expr
        destination_watermark_column = m_df.destination_watermark_column
        destination_update_changes_only = m_df.destination_update_changes_only
        
        # validator metadata
        metadata_validator_yml = m_df.validator

        # prepare local variables
        destination_table_name = m_df.destination_table_name
        destination_table_full_name = f"{destination_lakehouse}.{m_df.destination_table_name}"
        destination_table_full_path = f"/{destination_lakehouse_guid}/Tables/{m_df.destination_table_name.replace('.', '/')}"
        if self.debug:
            self.logger.debug(f"destination_table_full_name: {destination_table_full_name}")
            self.logger.debug(f"destination_table_full_path: {destination_table_full_path}")

        # run the destination_write_prescript
        script_path = f"{Environment.root_path_metadata}{m_df.destination_write_prescript}"  
        if not (script_path is None or script_path == ""):
            self.logger.info(f"write prescript start")
            # get the sql script
            with open(script_path, 'r') as file:
                sqlscript = file.read()
            DeltaTableUtil.run_sql_script(sqlscript, self.spark, self.debug)
            self.logger.info(f"write prescript end")

        # check destination table 
        if not self.spark.catalog.tableExists(destination_table_full_name):
            msg = f"table {destination_table_full_name} does not exist, please create the table."
            self.logger.error(msg)
            raise Exception(msg)

        # use the schema of the destination table if source data schema is not defined
        if source_data_schema is None or source_data_schema == "":
            source_data_schema = self.spark.read.table(destination_table_full_name).schema
            if self.debug:
                self.logger.debug(f"warning: source_data_schema not defined, use destination table schema instead")            
        else:
            source_data_schema = source_data_schema + ", _corrupt_data string"


        # get the loaded files list
        destination_files_df = self.spark.sql(f"select distinct file_name, file_timestamp from mdd.etl_job_files where table_name = '{destination_table_name}'")
        destination_files = list((row["file_name"], row["file_timestamp"]) for row in destination_files_df.collect())
        if self.debug:
            self.logger.debug(f"destination_files_df: {destination_files_df.count()}")
            display(destination_files_df.sort(destination_files_df.file_name.desc()))
            self.logger.debug(f"destination_files: {destination_files}")

        # get the new files
        file_manifest = FileManifest(self.spark, self.debug)
        df_manifest, manifest_files, manifest_groups = file_manifest.get(source_data_path, source_file_name_regex, destination_files, self.data_sync_options)

        # loop the file groups, read the data and write to destination
        self.logger.info(f"{m_df.dataflow_type} start: {destination_table_name}") 
        
        self.logger.info(f"files path: {source_data_path}")
        self.logger.info(f"files in total: {manifest_files}")
        if manifest_files > 0:
            self.logger.info(f"files per batch: {self.data_sync_options['files_per_batch']}")
            self.logger.info(f"batches in total: {len(manifest_groups)}")

        i = 0
        for file_path_list in manifest_groups[:]:
            i += 1
            self.logger.info(f"batch #{i} start")
            self.logger.info(f"files in batch: {len(file_path_list)}")

            source_options = {
                    "source_format": source_data_format,
                    "source_read_options": source_data_read_options,
                    "source_schema":source_data_schema
                }
            read_start_timestamp = mdt.datetime.utcnow()
            datareader = DataReader.create(source_data_format, source_options, self.spark, self.debug)
            if datareader is None:
                err_msg = f"the data reader for '{source_data_format}' is not registered"
                self.logger.error(err_msg)
                raise Exception(err_msg)

            self.logger.info(f"read start")
            batch_data_df = datareader.read(file_path_list)
            
            if batch_data_df is not None:
                batch_data_df.cache()
                self.logger.info(f"read rows in total: {batch_data_df.count()}")

            read_end_timestamp = mdt.datetime.utcnow()

            self.logger.info(f"write start")
            write_start_timestamp = mdt.datetime.utcnow()
            write_end_timestamp = mdt.datetime.utcnow()
            imported_files_df = df_manifest.where(df_manifest.file_path.isin(file_path_list)) 
                                                                                
            if batch_data_df is not None:
                
                # write the validated data into destination table
                write_config = {
                    "source_table_name": None,
                    "destination_table_full_path": destination_table_full_path,
                    "destination_table_name": destination_table_name,
                    "destination_write_mode": destination_write_mode,
                    "destination_write_options": destination_write_options,
                    "destination_projected_sql": destination_projected_sql,
                    "metadata_validator_yml": metadata_validator_yml,
                    "destination_primarykey": destination_primarykey,
                    "destination_deduplication_expr": destination_deduplication_expr,
                    "destination_watermark_column": destination_watermark_column,
                    "destination_update_changes_only": destination_update_changes_only,
                    "task_run_id": self.task_run_id,
                    "task_start_timestamp": self.task_start_timestamp,
                    "job_run_id": self.job_run_id

                }
                datawriter = DataWriter(batch_data_df, write_config, self.spark, self.debug)
                datawriter.write()
                write_end_timestamp = mdt.datetime.utcnow()

                total_rows_df = batch_data_df.withColumns({"file_name": "_metadata.file_name", "file_modification_timestamp": "_metadata.file_modification_time"}) \
                                        .groupBy("file_name", "file_modification_timestamp")\
                                        .agg(count("*").alias("rows_read"))

                total_imported_sql = f"""
                                select 
                                    _source_name as file_name
                                    ,_source_timestamp as file_modification_timestamp
                                    ,count(*) as rows_onboarded
                                    ,sum(case when _corrupt_data is not null and _corrupt_data <> '' then 1 else 0 end) as rows_corrupted
                                    ,sum(case when _deleted_by_source then 1 else 0 end) as rows_deleted_by_source
                                    ,sum(case when _deleted_by_validation then 1 else 0 end) as rows_deleted_by_validation
                                from {destination_table_name}
                                where _record_timestamp >= '{write_start_timestamp}'
                                group by _source_name, _source_timestamp"""
                total_imported_rows_df = self.spark.sql(total_imported_sql)

                imported_files_df = imported_files_df.alias("t1").join(total_rows_df.alias("t2"), ["file_name", "file_modification_timestamp"], "left") \
                                        .join(total_imported_rows_df.alias("t3"), ["file_name", "file_modification_timestamp"], "left") \
                                        .select("t1.*", "t2.rows_read", "t3.rows_onboarded", "t3.rows_corrupted", "t3.rows_deleted_by_source", "t3.rows_deleted_by_validation") \
                                        .fillna({"rows_read": 0}).fillna({"rows_onboarded": 0}).fillna({"rows_corrupted": 0}).fillna({"rows_deleted_by_source": 0}).fillna({"rows_deleted_by_validation": 0})
            else:
                imported_files_df = imported_files_df.withColumn("rows_read", lit(long(0))).withColumn("rows_onboarded", lit(long(0))).withColumn("rows_corrupted", lit(long(0))) \
                                                        .withColumn("rows_deleted_by_source", lit(long(0))).withColumn("rows_deleted_by_validation", lit(long(0)))

            # remove the cache of the dataframe
            batch_data_df.unpersist()

            # save the state of the imported files with timestamp
            #imported_files_df.printSchema()
            
            imported_files_df = (
                imported_files_df.withColumn("table_name", lit(destination_table_name))
                .withColumn("log_timestamp", lit(current_timestamp()))
                .withColumn("data_sync_mode", lit(self.data_sync_options["data_sync_mode"]))
                .withColumn("data_write_mode", lit(destination_write_mode))
                .withColumn("read_start_timestamp", lit(read_start_timestamp))
                .withColumn("read_end_timestamp", lit(read_end_timestamp))
                .withColumn("write_start_timestamp", lit(write_start_timestamp))
                .withColumn("write_end_timestamp", lit(write_end_timestamp))
                .withColumn("job_run_id", lit(self.job_run_id))
                .withColumn("task_run_id", lit(self.task_run_id))
                .selectExpr(
                    "concat(file_name, '_', cast(file_modification_timestamp as string)) as file_run_id",
                    "file_name",
                    "file_modification_timestamp as file_timestamp",
                    "file_date",
                    "file_path",
                    "table_name",
                    "data_sync_mode",
                    "data_write_mode",
                    "rows_read",
                    "rows_onboarded",
                    "rows_corrupted",
                    "rows_deleted_by_source",
                    "rows_deleted_by_validation",
                    "read_start_timestamp",
                    "read_end_timestamp",
                    "write_start_timestamp",
                    "write_end_timestamp",
                    "task_run_id",
                    "job_run_id",
                    "log_timestamp"
                )
            ) 
                           
            imported_files_df.write.mode("append").option("mergeSchema", "true").saveAsTable("mdd.etl_job_files")
            
            # archive or delete the files 
            files = DeltaTableUtil.column_to_list(imported_files_df, "file_path")
            if source_file_cleanup is not None:
                if source_file_cleanup == "move":
                    FileUtil.archive_files(files)
                elif source_file_cleanup == "delete":
                    FileUtil.delete_files(files)
                else:
                    raise ValueError(f"the cleanup should be 'move' or 'delete'")
        # end for

        
        # run the destination_write_prescript
        script_path = f"{Environment.root_path_metadata}{m_df.destination_write_postscript}"
        if not (script_path is None or script_path == ""):
            self.logger.info(f"write postscript start")
            # get the sql script
            with open(script_path, 'r') as file:
                sqlscript = file.read()
            DeltaTableUtil.run_sql_script(sqlscript, self.spark, self.debug)
            self.logger.info(f"write postscript end")

        # run table validator
        if metadata_validator_yml is not None and metadata_validator_yml != "":
            self.logger.info(f"table validation start")
            DataValidator.validate_query(
                table_name = destination_table_name,
                yaml_path = metadata_validator_yml,
                spark = self.spark,
                logger = self.logger,
                task_run_id = self.task_run_id,
                task_start_timestamp = self.task_start_timestamp,
                job_run_id = self.task_run_id
            )
            self.logger.info(f"table validation end")

        self.logger.info(f"{m_df.dataflow_type} end: {destination_table_name}") 
    # function end: run

