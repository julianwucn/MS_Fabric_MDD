#!/usr/bin/env python
# coding: utf-8

# ## datareader
# 
# New notebook

# In[1]:


# import
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Callable, Type, Optional


# In[ ]:


class DataReader:
    registry = {}

    @classmethod
    def register(cls, name: str) -> Callable[[Type["DataReaderBase"]], Type["DataReaderBase"]]:
        def inner_wrapper(wrapped_class: Type["DataReaderBase"]) -> Type["DataReaderBase"]:
            cls.registry[name] = wrapped_class
            return wrapped_class
        return inner_wrapper

    @classmethod
    def create(cls, name:str, source_options, spark, debug) -> DataReaderBase:
        if name not in cls.registry:
            raise ValueError(f"DataReader '{name}' is not registered. Available classes are {cls.registry}")

        datareader_class = cls.registry[name] 
        datareader = datareader_class(source_options, spark, debug)

        return datareader


# In[ ]:


class DataReaderBase(ABC):
    def __init__(self, source_options, spark, debug = False):
        self.source_options = source_options
        self.spark = spark
        self.debug = debug

    @abstractmethod
    def read(self, source_path) -> dataframe:
        pass

