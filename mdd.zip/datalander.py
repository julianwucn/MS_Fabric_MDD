#!/usr/bin/env python
# coding: utf-8

# ## datalander
# 
# New notebook

# In[ ]:


from env.mdd.metadata import *
from env.mdd.environment import Environment
from env.mdd.mddutils import *
from env.mdd.datalanders.datalander_base import DataLanderBase, DataLanderFactory


# In[ ]:


@DecoratorUtil.add_logger()
class DataLander:
    def __init__(self, metadata_lander_yml, spark, debug = False):
        self.metadata_lander_yml = metadata_lander_yml
        self.spark = spark
        self.debug = debug

    # import all data landers
    from importlib import import_module
    import env.mdd.datalanders as datalanders
    for module_name in datalanders.__all__:
        import_module(f"{datalanders.__name__}.{module_name}")

    @DecoratorUtil.log_function()
    def run(self):

        metadata_lander = Metadata_Lander(self.metadata_lander_yml, self.logger, True)
        source_server_options = metadata_lander.source_server_options
        server_type = source_server_options["server_type"]

        datalander = DataLanderFactory.create(server_type, self.metadata_lander_yml, self.spark, self.debug)
        if datalander is None:
            err_msg = f"the data lander for '{server_type}' is not registered"
            self.logger.error(err_msg)
            raise Exception(err_msg)

        datalander.run()


