#!/usr/bin/env python
# coding: utf-8

# ## datalander_base
# 
# New notebook

# In[1]:


from abc import ABC, abstractmethod
from typing import Callable


# In[2]:


class DataLanderBase(ABC):
    def __init__(self, metadata_lander_yml, spark,  debug = False):
        self.metadata_lander_yml = metadata_lander_yml
        self.spark = spark
        self.debug = debug

    @abstractmethod
    def run(self):
        pass


# In[3]:


class DataLanderFactory:
    registry = {}

    @classmethod
    def register(cls, name: str) -> Callable:
        def inner_wrapper(wrapped_class: DataLanderBase) -> Callable:
            cls.registry[name] = wrapped_class
            return wrapped_class

        return inner_wrapper

    @classmethod
    def create(cls, name:str, metadata_lander_yml, spark, debug) -> DataLanderBase:
        if name not in cls.registry:
            return None
        
        datalander_class = cls.registry[name] 
        datalander = datalander_class(metadata_lander_yml, spark, debug)

        return datalander

