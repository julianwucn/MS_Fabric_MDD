#!/usr/bin/env python
# coding: utf-8

# ## task
# 
# New notebook

# In[ ]:


# import
from env.mdd.metadata import *
from env.mdd.workflow import *
import logging


# In[ ]:


class Task:
    def __init__(self, metadata_task_yml, metadata_environment_yml, spark):
        function_name = "__init__"
        self.spark = spark
        logger_name = f"mdd.{self.__class__.__name__}"
        logger = logging.getLogger(logger_name)

        self.metadata_task = Metadata_Task(metadata_task_yml, False)
        self.metadata_environment_yml = metadata_environment_yml
        self.debug = self.metadata_task.debug
        self.active = self.metadata_task.active

        if self.debug:
            logger.debug(f"function begin: {function_name}")
            logger.debug(f"debug: {self.debug}")
            logger.debug(f"active: {self.active}")
            logger.debug(f"function end: {function_name}")

        self.logger = logger

    
    def run(self):
        function_name = "run"
        if self.debug:
            self.logger.debug(f"function begin: {function_name}")

        if self.active:
            workflows = self.metadata_task.workflows
            
            for workflow in workflows:
                metadata_workflow_yml = workflow["workflow"]
                debug = workflow["debug"]
                active = workflow["active"]
                if self.debug:
                    self.logger.debug(f"metadata_workflow_yml: {metadata_workflow_yml}")
                    self.logger.debug(f"debug: {debug}")
                    self.logger.debug(f"active: {active}")
                if active:
                    workflow = Workflow(metadata_workflow_yml, self.metadata_environment_yml, self.spark, debug)
                    workflow.run()
            # end for loop
        else:
            if self.debug:
                self.logger.warning("the task is not active")

        if self.debug:
            self.logger.debug(f"function end: {function_name}")
    #end function run

